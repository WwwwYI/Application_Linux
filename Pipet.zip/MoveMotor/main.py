import MotorDriver
from MotorDriver import CDM57_StepMotor

import Pipet
import time
# 所有的序号 从 1 开始，与数组不同
# 试剂瓶的位置 [1,[1,1]] , [1,[1,2]] , [2,[1,1]]
# 试管的位置 [2, [5,1] ] [ 2, [5,2] ]
# 反应所需的溶液体积 [[200,175],[380,390],[100,110]]
# 用二维数组表示移液方案
# 试剂瓶位置 第一行第二列盒子中，第三行，第四列 的瓶位的瓶子
# 试管位置 第一行第二列盒子中，第三行，第四列 的瓶位的试管
# 溶液体积是 第一个试剂瓶中 取200 进入第一个试管，取175，进入第二个试管，这个数组，列数对应试管，行数对应试剂瓶
# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    str = 'PlatformCoodinate'

    #xMotor.MotorSpeedSetting(1,204800)

    myPipet  = Pipet.CPipLiquid()
    myPipet.ReadCfg()
    myPipet.TransScheme([[1,[1,1]],[1,[1,2]]],[[2,[5,1]]],[[200],[370]])
    myPipet.ExcuteScheme()
    # myPipet.Axiszeroing(myPipet.xAxisState.MotorAddr)
    # myPipet.Axiszeroing(myPipet.yAxisState.MotorAddr)
    # myPipet.Axiszeroing(myPipet.zAxisState.MotorAddr)
    #myPipet.Axiszeroing(myPipet.retractiMoState.MotorAddr)
    #myPipet.Axiszeroing(myPipet.retractiMoState.MotorAddr)
    # myPipet.GoToXY(0,0)
    # myPipet.zAxisState.AxisAimP = 100
    # myPipet.SingleMove(myPipet.zAxisState)
    # myPipet.GoToXY(500, 250)
    # myPipet.GoToXY(550, 260)
    # myPipet.GoToXY(500, 240)
    # myPipet.GoToXY(490, 230)
    # myPipet.GoToXY(490, 220)
    # myPipet.GoToXY(490, 210)
    # myPipet.GoToXY(480, 210)
    # myPipet.GoToXY(470, 210)
    # myPipet.GoToXY(460, 210)
    # myPipet.GoToXY(60, 55)
    # myPipet.zAxisState.AxisAimP = 50
    # myPipet.SingleMove(myPipet.zAxisState)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
