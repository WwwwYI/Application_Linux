import time
import serial
import binascii
import crcmod.predefined
import threading
from queue import Queue




class CDM57_StepMotor:

    ser = serial.Serial('com20', 9600)  # 选择串口，并设置波特率

    def CombinaModbusData(self, slaveAddr, funcCode, regAddr, regNum, byteNum, regData):
        # slave_addr: 从机地址,
        # func_code: 功能码
        # reg_addr: 地址(查询/修改地址)
        # reg_num: 寄存器数据量
        # byte_num:字节数据量
        # data:待写入的数据

        _slaveAddr = hex(slaveAddr).replace('0x','').zfill(2)
        _funcCode = hex(funcCode).replace('0x', '').zfill(2)
        _modbusStr = _slaveAddr + _funcCode + regAddr

        if funcCode == 6: #功能06
            _regData = hex(regData).replace('0x', '').zfill(4)
            _modbusStr += _regData
        elif  funcCode == 16: #功能0x10
            _regNum = hex(regNum).replace('0x', '').zfill(4)
            _byteNum = hex(byteNum).replace('0x', '').zfill(2)
            _regData = hex(regData).replace('0x', '').zfill(8)
            _modbusStr += _regNum + _byteNum + _regData
        elif  funcCode == 3: #功能03
            _regNum = hex(regNum).replace('0x', '').zfill(4)
            _modbusStr += _regNum

        # 获取crc
        _crc16 = crcmod.predefined.Crc('modbus')
        _hexData = _modbusStr
        _hexData = binascii.unhexlify(_hexData)
        _crc16.update(_hexData)
        _result = hex(_crc16.crcValue)
        _result1 = _result[-2:]
        if len(_result) > 5:
            _result2 = _result[-4:-2]
        else:
            _result2 = '0' + _result[-3:-2]
        _result3 = _modbusStr + _result1 + _result2
        return  _result3

    #
    def SendModbusCmd(self, slaveAddr, funcCode, reg_Addr, regNum,byteNum,regData):
        _str = self.CombinaModbusData(slaveAddr, funcCode, reg_Addr, regNum,byteNum,regData)
        send_data = binascii.unhexlify(_str)
        # self.ser.write(send_data)  # 发送命令
        # #print('Send:',send_data.hex())
        # time.sleep(0.05)
        # 读取返回值
        _lenReturnData = 0  # 获取缓冲数据（接收数据）长度
        while _lenReturnData == 0:
            self.ser.write(send_data)  # 发送命令
            # print('Send:',send_data.hex())
            time.sleep(0.1)
            _lenReturnData = self.ser.inWaiting()
            if _lenReturnData > 0:
                _returnData = self.ser.read(_lenReturnData)  # 读取缓冲数据
                #print('Rev :' , _returnData.hex())
                return _returnData

    # 配置电机的 运行速度
    def MotorSpeedSetting(self,slaveAddr,  runSpeed):
        self.SendModbusCmd(slaveAddr, 16, '0026', 2, 4, runSpeed)

    def MotorTempSpeedSetting(self,slaveAddr,runSpeed):
        self.SendModbusCmd(slaveAddr, 16, '0028', 2, 4, runSpeed)
    # 电机归0位
    # 电机接线设置如下：
    # 全部使用左光耦
    # x轴，左 为 负方向，右 为 正方向，
    # y轴，后 为 负方向，前 为 正方向
    # z轴，上 为 负方向，下 为 正方向
    # 移液枪
    # dec 4101, 对应 hex 0x1005
    def MotorZeroing(self,slaveAddr):

        self.SendModbusCmd(slaveAddr, 6, '002a', 0, 0, 4101)

    def MoveMotorPulse(self, slaveAddr, Pulse):
        self.SendModbusCmd(slaveAddr, 16, '002b', 2, 4, Pulse)
    #
    def MoveMotorPostion(self, slaveAddr, postion):
        # mm 转换为脉冲
        # if slaveAddr == 1 or slaveAddr == 2 or slaveAddr == 3:
        motorPulse = int( postion / 72 * 51200 )
        self.SendModbusCmd( slaveAddr, 16, '002b', 2, 4, motorPulse)
    #
    def MoveMotorSpeed(self, slaveAddr, direction):
        """
        0 ————> 反转
        1 ————> 正传
        """
        if direction == 0:
            self.SendModbusCmd(slaveAddr, 6, '002a', 0, 0, 0)
        elif direction == 1:
            self.SendModbusCmd(slaveAddr, 6, '002a', 0, 0, 16)


    #
    def GetMotorPotion(self, slaveAddr):

        _postion = self.SendModbusCmd( slaveAddr, 3, '002b', 2, 0, 0)

        _postion1 = int.from_bytes(_postion[4:7] , 'big')
        #print('position1:',_postion1)
        if _postion1 == 0:
            _postion2 = 0
        else:
            _postion2 = 16777216 - _postion1
        _postion3 = _postion2 / 51200 * 72
        return _postion3

    def GetMotorPotionPulse(self, slaveAddr):
        _position = self.SendModbusCmd(slaveAddr, 3, '002b', 2, 0, 0)

        _position1 = int.from_bytes(_position[4:7], 'big')
        if slaveAddr == 1 or slaveAddr == 2 or slaveAddr ==3:
            #print('positon_1 = ',_postion1)
            if _position1 == 0:
                _position2 = 0
            else:
                _position2 = 16777216 - _position1

        elif slaveAddr == 4 or slaveAddr == 5 or slaveAddr ==6:
            _position2 =_position1

        return _position2


    def ResetMotor(self, slaveAddr):
        time.sleep(0.2)
        print("start reset")
        self.SendModbusCmd(slaveAddr, 6, '002d', 0, 0, 1)  #关闭使能
        print("reset done")
        time.sleep(0.2)
        self.SendModbusCmd(slaveAddr, 6, '002d', 0, 0, 0)   #打开使能
        time.sleep(0.2)

    def IsAxisReachTarget(self, slaveAddr, aimP):
        realPx = self.GetMotorPotionPulse(slaveAddr)
        #print('axix is:',slaveAddr,'realPx:',realPx,'aimP:',int(aimP / 72 * 51200) )
        if realPx == int(aimP / 72 * 51200) :
            return True
        else:
            return False

    def IsAxisStop(self,slaveAddr,amiP):
        while True:
            if self.IsAxisReachTarget(slaveAddr, amiP):
                time.sleep(0.2)
                break

if __name__ == '__main__':
    motor = CDM57_StepMotor()
    # motor.MotorZeroing(4)
    # motor.IsAxisStop(4, 0)

    # print(motor.GetMotorPotionPulse(4))
    # time.sleep(0.5)
    motor.MoveMotorPostion(4,360)
    motor.IsAxisStop(4, 360)
    motor.MoveMotorPostion(4, 216)
    motor.IsAxisStop(4, 216)














