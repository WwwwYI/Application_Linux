# -*- coding: utf-8 -*-
import psycopg2
from dbutils.pooled_db import PooledDB
import configparser
import os
import json
import ast
import common.constconfig as commconfig

config = configparser.ConfigParser()
conf_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
r = config.read(conf_path + "/DotestData.conf")
pg_host = config.get("Postgres", "PG_HOST")
pg_port = config.get("Postgres", "PG_PORT")
pg_user = config.get("Postgres", "PG_USER")
pg_password = config.get("Postgres", "PG_PASSWORD")
pg_db = config.get("Postgres", "PG_DB")

POLL = PooledDB(creator=psycopg2,
                mincached=0,
                maxcached=0,
                maxshared=0,
                maxconnections=100,
                blocking=False,
                maxusage=None,
                setsession=None,
                reset=True,
                failures=None,
                ping=1,
                host=pg_host,
                port=int(pg_port),
                user=pg_user,
                password=pg_password,
                database=pg_db)
                #charset=pg_charset)

class DB(object):
    def __init__(self):
        self.conn, self.cursor= self.db_connect()

    def db_connect(self):
        try:
            conn = POLL.connection()
            cursor = conn.cursor()
            return conn,cursor
        except Exception as e:
            #logger.error("Connect db error: %s" % e)
         #   print("Connect db error: %s" % e)
            raise

    def insert(self, table, data):
        if isinstance(data, dict):
            data = json.dumps(data, ensure_ascii=False)
        sql = "INSERT INTO %s VALUES ('%s'::jsonb)"%(table,data)
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
            #logger.error("Insert error: %s" % e)
            print("Insert error: %s" % str(e))
            self.conn.rollback()
            return False, str(e)
        finally:
            self.close_db()

    def insert_by_kwargs(self,table,**kwargs):
        key = []
        value = []

        for k,v in kwargs.items():
            key.append(k)
            if isinstance(v,dict):
                data = json.dumps(v['data'],ensure_ascii=False)
                value.append(data)

            else:
                value.append(v)
        column = ','.join(key)
        sql = "INSERT INTO "+table+" ("+column+") VALUES "+str(tuple(value))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
            #print("Insert error: %s" % e)
            self.conn.rollback()
            return False, str(e)
        finally:
            self.close_db()


    def test_insert(self,table,**kwargs):
        steps_data = json.dumps(kwargs['steps'],ensure_ascii=False)
        sql = "INSERT INTO %s VALUES ('%s','%s','%s','%s','%s','%s'::jsonb,'%s','%s')" %(table,kwargs['vulname'],kwargs['tcname'],kwargs['vultag'],kwargs['vultype'],kwargs['risklevel'],steps_data,kwargs['phrase'],kwargs['testid'])
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
            #print("Insert error: %s" % e)
            self.conn.rollback()
            return False, str(e)
        finally:
            self.close_db()
    
    def testcasecapec_insert(self,table,**kwargs):
        for k,v in kwargs.items():
            tmp = v.replace("'",r"\"")
            kwargs[k] = tmp
        keys = ', '.join(kwargs.keys())
        sql = "INSERT INTO {} ({}) VALUES {}".format(table,keys,tuple(kwargs.values()))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
            #print(kwargs['name'])
            print("Insert error: %s" % e)
            self.conn.rollback()
            return False, str(e)
        finally:
            self.close_db()
    
    def testcaseout_insert(self,table,**kwargs):
        keys = ', '.join(kwargs.keys())
        sql = "INSERT INTO {} ({}) VALUES {}".format(table,keys,tuple(kwargs.values()))
        #print(sql)
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
            print("Insert error: %s" % e)
            self.conn.rollback()
            return False, str(e)
        finally:
            self.close_db()


    def insert_result_db(self,table,port,phrase,**args):
        
        for entcname,arg in args.items():
            tcname = arg['tcname']
            del arg['tcname']
            if phrase == 'CAPEC' or phrase == 'Publicvul' or phrase == 'Event':
                org_data = {"result":"","phrase":phrase,"tcname":tcname}
                org_data.update(arg)
            else:
                org_data = {"celerytask_id":"","args":arg,"result":"","phrase":phrase,"tcname":tcname}
        data = json.dumps(org_data,ensure_ascii=False)
        sql = "INSERT INTO %s"%table
        sql += " VALUES (%s,%s,%s::jsonb)"
        tmp_list  = [entcname,port,data]
        
        try:
            self.cursor.execute(sql,tuple(tmp_list))
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
        #    print("Insert error: %s" % e)
            self.conn.rollback()
            return False, str(e)
        finally:
            self.close_db()

    def select_by_kwargs(self, table,start=-1,offset=0, **kwargs):
        flag = True
        tmp_list = []
        if not kwargs:
            sql = "SELECT DISTINCT * FROM %s  " %table        
        else:
            sql = "SELECT DISTINCT * FROM %s WHERE " %table
            for k, v in kwargs.items():
                is_dict = isinstance(v,dict)
                if flag:
                    if is_dict:
                        sql += " data ->>'%s' ="%k
                        sql += " %s "
                        tmp_list.append(v['data'])
                    else:
                        sql += " %s = "%k
                        sql += " %s"
                        tmp_list.append(v)
                    flag = False
                else:
                    if is_dict:
                        sql += " and data ->>'%s' ="%k
                        sql += " %s "
                        tmp_list.append(v['data'])
                    else:
                        sql += " and %s = "%k
                        sql += " %s"
                        tmp_list.append(v)
        
        if (start != -1):
            sql += " limit %d offset %d "%(offset,start)
        try:
            self.cursor.execute(sql,tuple(tmp_list))
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()

    def select_count_by_kwargs(self, table, **kwargs):
        flag = True
        tmp_list = []
        if not kwargs:
            sql = "SELECT DISTINCT count(*) FROM %s  " %table
        else:
            sql = "SELECT DISTINCT count(*) FROM %s WHERE " %table
            for k, v in kwargs.items():
                is_dict = isinstance(v,dict)
                if flag:
                    if is_dict:
                        sql += " data ->>'%s' ="%k

                        sql += " %s "
                        tmp_list.append(v['data'])
                    else:
                        sql += " %s = "%k
                        sql += " %s"
                        tmp_list.append(v)
                    flag = False
                else:
                    if is_dict:
                        sql += " and data ->>'%s' ="%k
                        sql += " %s "
                        tmp_list.append(v['data'])

                    else:
                        sql += " and %s ="%k
                        sql += " %s "
                        tmp_list.append(v)
        try:
            self.cursor.execute(sql,tuple(tmp_list))
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()

    def confuse_select_count_by_kwargs(self, table, **kwargs):
        flag = True
        tmp_list = []
        if not kwargs:
            sql = "SELECT DISTINCT count(*) FROM %s  " %table
        else:
            sql = "SELECT DISTINCT count(*) FROM %s WHERE " %table
            for k, v in kwargs.items():
                is_dict = isinstance(v,dict)
                if flag:
                    if is_dict:
                        sql += " data ->>'%s' "%k
                        sql += " like %s "
                        tmp_list.append('%'+v['data']+'%')
                    else:
                        sql += " %s like "%k
                        sql += "%s"
                        tmp_list.append('%'+v+'%')
                    flag = False
                else:
                    if is_dict:
                        sql += " and data ->>'%s' like"%k
                        sql += " %s "
                        tmp_list.append('%'+v['data']+'%')

                    else:
                        sql += " and %s like "%k
                        sql += "%s"
                        tmp_list.append('%'+v+'%')
        try:
            self.cursor.execute(sql,tuple(tmp_list))
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()

                    
    def confuse_select_by_kwargs(self, table,start=-1,offset=0, **kwargs):
        flag = True
        tmp_list = []
        if not kwargs:
            sql = "SELECT DISTINCT * FROM %s  " %table
        else:
            sql = "SELECT DISTINCT * FROM %s WHERE " %table
            for k, v in kwargs.items():
                is_dict = isinstance(v,dict)
                if flag:
                    if is_dict:
                        sql += " data ->>'%s' like"%k
                        sql += " %s "
                        tmp_list.append('%'+v['data']+'%')
                    else:
                        sql += " %s like "%k
                        sql +=  "%s"
                        tmp_list.append('%'+v+'%')
                    flag = False
                else:
                    if is_dict:
                        sql += " and data ->>'%s' like"%k
                        sql += " %s "
                        tmp_list.append('%'+v['data']+'%')
                    else:
                        sql += " and  %s like "%k
                        sql +=  "%s"
                        tmp_list.append('%'+v+'%')

        if (start != -1):
            sql += " limit %d offset %d "%(offset,start)
        #print(sql)
        try:
            self.cursor.execute(sql,tuple(tmp_list))
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()
                                                                               

    def select_by_phrase_flag(self, table, **kwargs):

        sql = "SELECT DISTINCT * FROM %s WHERE phrase = '%s' and vultag like '%%%s%%'" %(table,kwargs['phrase'],kwargs['flag'])

        try:
            self.cursor.execute(sql)
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()
        
    def select_vulinfo_by_phrase(self, table, **kwargs):
        
        if 'vulname' in kwargs:
            #if isinstance(kwargs['vulname'])
            flag = True
            for k,v in kwargs['vulname'].items():
                if flag:
                    sql = "SELECT %s FROM %s WHERE %s = '%s' "%(kwargs['name'],table,k,v)
                else:
                    sql += "and %s = '%s'"%(k,v)
            #sql = "SELECT %s FROM %s WHERE vulname = '%s'" %(kwargs['name'],table,kwargs['vulname'])
        else:
            sql = "SELECT %s FROM %s " %(kwargs['name'],table)
        #print(sql)
        try:
            self.cursor.execute(sql)
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()
    
    def select_specinfo_by_table(self, table, name,conditions={}):
        flag = True
        tmp_list = []
        if conditions == {}:
            sql = "SELECT DISTINCT %s FROM %s " %(name,table)
        else:
            sql = "SELECT DISTINCT %s FROM %s WHERE " %(name,table)
            for k, v in conditions.items():
                is_dict = isinstance(v,dict)
                if flag:
                    if is_dict:
                        sql += " data ->>'%s' ="%k

                        sql += " %s "
                        tmp_list.append(v['data'])
                    else:
                        sql += " %s = "%k
                        sql += " %s"
                        tmp_list.append(v)
                    flag = False
                else:
                    if is_dict:
                        sql += " and data ->>'%s' ="%k
                        sql += " %s "
                        tmp_list.append(v['data'])

                    else:
                        sql += " and %s = "%k
                        sql += " %s "
                        tmp_list.append(v)

        try:
            self.cursor.execute(sql,tuple(tmp_list))
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()

    def select_specinfo_by_phrase(self, table, name,phrase):

        sql = "SELECT DISTINCT %s FROM %s where phrase = '%s'" %(name,table,phrase)
        try:
            self.cursor.execute(sql)
            tmp = self.cursor.fetchall()
            if tmp:
                return True, tmp
            else:
                return True, None
        except Exception as e:
            print(str(e))
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()


        

    def create_table(self, pttask_id):
        sql_create = "CREATE TABLE IF NOT EXISTS t_info_%s_result (entcname text,port text,data jsonb,PRIMARY KEY(entcname,port))" % pttask_id
        try:
            self.cursor.execute(sql_create)
            self.conn.commit()
            return True, ""
        except Exception as e:
            print(str(e))
            self.conn.rollback()
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()

    """
    名称:update_by_id_args
    功能:更新数据库字段（1个或多个）
    函数说明:接口支持普通关系型数据库类型（int/char/text等类型）和特殊类型（json/jsonb类型）字段的更行，为保证函数对不同类型字段的兼容性，通过入参判断数据类型，说明如下：
    1、普通数据类型入参格式:{key':value}，其中key为待更新列名称，value为待更新数值内容
    2、json/jsonb类型入参格式:{'key':{'data':value}}，其中，key为待更新列名，data为固定值，value为待更新数值内容
    ps:若更新jsonb整体内容，入参格式按照普通数据设置，若更新jsonb中部分数据，入参格式按照特殊数据设置
    """
    def update_by_id_args(self, table, conditions,**kwargs):
        #print(conditions)
        flag = True
        data_flag = True
        sql = "UPDATE %s SET " % table
        tmp_list = []
        for key,value in kwargs.items():
            if data_flag:
                if isinstance(value,dict) :
                    update_data = value['data']
                    if isinstance(update_data,dict) or isinstance(update_data,list):
                        data_json = json.dumps(update_data)
                        sql += "data=(jsonb_set(data::jsonb, '{%s}', " % key
                        sql += "%s::jsonb))  " 
                        tmp_list.append(data_json)
                    else:
                        sql += "data=jsonb_set(data, '{%s}', " %key 
                        sql += "%s)  "
                        tmp_list.append('"'+update_data+'"')
                else:
                    if isinstance(value,list):
                        value = json.dumps(value)

                    sql += "%s = " % key
                    sql += "%s  "  
                    tmp_list.append(value)
                data_flag = False
            else:
                if isinstance(value,dict):
                    update_data = value['data']
                    if isinstance(update_data,dict) or isinstance(update_data,list):
                        data_json = json.dumps(update_data)
                        sql += ", data=(jsonb_set(data::jsonb, '{%s}', " % key
                        sql += "%s::jsonb))  "
                        tmp_list.append(data_json)
                    else:
                        sql += ", data=jsonb_set(data, '{%s}', " %key
                        sql += "%s)  "
                        tmp_list.append('"'+update_data+'"')
                else:
                    if isinstance(value,list):
                        value = json.dumps(value)
                    sql += " , %s = " % key
                    sql += "%s  "
                    tmp_list.append(value)
        for k, v in conditions.items():
            
            if flag:
                if isinstance(v,dict):
                    sql += " WHERE data ->>'%s' ="%k
                    sql += " %s "
                    tmp_list.append(v['data'])
                else:
                    sql += " WHERE %s = " %k
                    sql += "%s "
                    tmp_list.append(v)
                flag = False
            else:
                if isinstance(v,dict):
                    sql += " data ->>'%s' ="%k
                    sql += " %s "
                    tmp_list.append(v['data'])
                else:
                    sql += "and %s = " %k
                    sql += "%s"
                    tmp_list.append(v)

        #print(sql)
        
        try:
            self.cursor.execute(sql,tuple(tmp_list))
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
            #logger.error("Update error: %s" % e)
            print(str(e))
            self.conn.rollback()
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()


    def delete_by_id(self, table, **kwargs):
        value = []
        flag = True
        for k,v in kwargs.items():
            if flag:
                if isinstance(v,dict):
                    sql = "DELETE FROM %s WHERE data ->> '%s' = " % (table, k)
                    sql += " %s" 
                    value.append(v['data'])
                else:
                    sql = "DELETE FROM %s WHERE %s = "% (table, k)
                    sql += "%s" 
                    value.append(v)
                flag = False
            else:
                if isinstance(v,dict):
                    sql += " and data ->> '%s' = " %k
                    sql += "%s"
                    value.append(v['data'])
                else:
                    sql += " and  %s = "%k
                    sql += "%s"
                    value.append(v)
        try:
            self.cursor.execute(sql,tuple(value))
            self.conn.commit()
            return True, self.cursor.rowcount
        except Exception as e:
            #logger.error("Delete by id error: %s" % e)
            self.conn.rollback()
            return False, str(e)
        finally:
            self.cursor.close()
            self.conn.close()


    def close_db(self):
        #print('close db')
        self.cursor.close()
        self.conn.close()

