# -*- coding: utf-8 -*-

#import common.const as CONST
from enum import Enum

TEST_OVER_CODE = 0
ENV_ERROR_CODE = -1
RUNNING_CODE = -2
MIS_ARG_CODE = -3
RESULT_NOT_EXITS = -4
NOT_START_CODE = -5
FILE_CODE = 'file'
TXT_CODE = 'txt'
TASK_RUNNING = '进行中'
TASK_COMPLETE = '已完成'
TASK_ABORT = '中止'
TASK_NOSTART = '未开始'
TASK_OK = '测试通过'
TASK_NOK = '测试不通过'
LOGIN_OK = 20000
LOGIN_FAILD = 40001
ILLEGAL_TOKEN = 50008
SERVER_BUSY = 50012
TOKEN_EXPIRED = 50014
SERVER_EXCEPTION = 50011
PTTASK_NOT_EXITS = 201
DOS_TIME = 300
WAIT_TIME = 120
CONNECTIONS = 1024
DEFAULT_HEADER = 'Connection: keep-alive'
TESTCASETIMEOUT = 3600
METASCANTIMEOUT = 7200

OK = "Success"
NOK = "Failed"
NT = "NT"
RUNNING = "Test is running"
NOSTART = "Test not start"
EXCEPTION = "Tool running failed"
ERROR = "missing required arguments"
TIMEOUT = "timeout"
ACCOUNT_ERROR = "Username or password is wrong"
LOGIN_SUCCESS = "Login success"
KALI_TABLE = "t_info_ptenvironment"
TESTCASE_TABLE = "t_info_testcase"
ACCOUNT_TABLE = "t_info_account"
TASKSTATUS_TABLE = "t_info_pttaskstatus"
THREAT_TABLE = "t_info_threatintelligence"
THREAT_TABLE_TMP = "t_info_threatintelligencetmp"
EVENTTESTCASE_TABLE = "t_info_testcaseout"
CAPEC_TABLE = "t_info_testcasecapec"
DOSRESULT_TABLE = "t_info_dosspecial"
CVE_TABLE = "t_info_componentcve"
CVE_TABLE_TMP = "t_info_componentcvetmp"
#DOSRESULT_TABLE = "dos_special_result"


FILE_PATH='/root/Downloads/Result/'  
FILE_EXC_PATH='/root/Downloads/Result/ExtractResult/' 
DOWNLOAD_PATH = "/home/automan/Documents/ScanResult/"   
TCPARAM_PATH = "/home/automan/Documents/CPE_UC/Dot-istest/tcparam.yaml"
FIREWARE_PATH = '/home/automan/Downloads/'
DOSRESULT_PATH = '/home/automan/Downloads/dosresult.xml'
KALI_TOOL_PATH = '/root/Downloads/kali/'
REPORTTEMPLATE_PATH = '/home/automan/Documents/CPE_UC/Dot-istest/PTES/Reporting/'


WB_TAG = ['linux','all','dns','ftp','ipv6','mqtt','ntp','samba','snmp','ssh','telnet','tr069','tr064','upnp','sip','wifi','camera','http','tls','java','dbus','android']
DEFAULT_PORT = "1-1000,1900,1883,5060,7547,7777,8080,8443,8883,8887,15924,17998-18000,32767,32768,58000"
AttackModeType = ['配置错误','代码问题','资源管理错误','数字错误','信息泄露','竞争条件','输入验证','缓冲区错误','格式化字符串','跨站脚本','路径遍历','后置链接','SQL注入','注入','代码注入','命令注入','操作系统命令注入','安全特征问题','授权问题','信任管理','加密问题','未充分验证数据可靠性','跨站请求伪造','权限许可和访问控制','访问控制错误','资料不足','拒绝服务','信息收集','模糊测试']
METAIGNORE=['linux/http/atutor_filemanager_traversal','linux/http/netgear_wnr2000_rce']
