# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session, make_response
import json
import random
import string
import common.constconfig as config

parser = reqparse.RequestParser()


class Upload(Resource):
    def post(self):
        f = request.files['file']
        print(f.filename)
        f.save(config.FIREWARE_PATH+f.filename)
        return {"code":20000,"data":{"msg":"upload success"}}

