# -*- coding: utf-8 -*-

import os
import time
from common.redis import RedisTool
import json
from xml.dom import minidom
from common.db import DB
from celeryworker.celerytask.tasks import run_fuction
from celery.result import AsyncResult
import common.constconfig as config
from celery import chain
import yaml
import codecs
from flask import session



def join_insert_data(pentask_id, celery_id, phrase, test_name, **args):
    table = "t_info_"+pentask_id+"_result"
    data = {"celerytask_id":celery_id,"args":args,"result":"","phrase":phrase,"testcase":test_name}
    return table,data

def get_redis_result(celery_id):
    orgin_data = RedisTool.get('celery-task-meta-'+celery_id)
    if(orgin_data is None):
        return None
    json_data = json.loads(orgin_data)
    status = json_data['status']
    if(status != 'SUCCESS'):
        return None
    return json_data['result']

def getip(ethname):
    ipv4 = os.popen('ip addr show '+ethname+' | grep "\<inet\>" | awk \'{ print $2 }\' | awk -F "/" \'{ print $1 }\'').read().strip()
    print(ipv4)
    return ipv4

def get_port_from_xml(filepath):
    result = []
    try:
        dom = minidom.parse(filepath)
        root = dom.documentElement
        ports = root.getElementsByTagName('port')
        if ports.length != 0:
            for node in ports:
                port_info = {}
                port = node.getAttribute('portid')
                proto = node.getAttribute('protocol')
                states = node.getElementsByTagName('state')[0]
                if states:
                    state = states.getAttribute('state')
                else:
                    state = 'unknown'
                services = node.getElementsByTagName('service')
                if services:
                    service = services[0].getAttribute('name')
                    if service == 'netbios-ssn':
                        service = 'samba'
                    if services[0].getAttribute('version') :
                        version = services[0].getAttribute('version') 
                    else :
                        version = 'unknown'
                else:
                    service = 'unknown'
                    version = 'unknown'

                port_info = {'port':port,'protocol':proto,'state':state,'service':service,'version':version}
                result.append(port_info)
    except:
        print('get dom failed')    
    return result
 
def get_cpe_information(table,tcname):
    port = ''
    r,res = DB().select_data_by_tcname(table,tcname,port)
    #print(res)
    return {tcname:eval(res)['test_result']}
   
def match_db_by_cpeinfo(pentask_id,phrase,cpeinfo):
    static_table = ''
    #if phrase == 'Event':
     #   testcase_table = config.EVENTTESTCASE_TABLE
    if phrase == 'Publicvul':
        static_table = config.THREAT_TABLE
    elif phrase == 'Event':
        static_table = config.EVENTTESTCASE_TABLE
    elif phrase =='CVE':
        static_table = config.CVE_TABLE
    else:
        static_table = config.TESTCASE_TABLE


    f = codecs.open(config.TCPARAM_PATH,'r','utf-8')
    param_config = yaml.safe_load(f)    #获取用例参数配置文件信息
    f.close()
    table = 't_info_'+pentask_id+'_result'
    task_args = {'pttask_id':{'data':pentask_id}}
    r,result = DB().select_by_kwargs(config.TASKSTATUS_TABLE,**task_args)
    task_data = result[0][0]
    protol = ''
    args = {}
    comm_args = {}
    if phrase in ['Publicvul','Event','CVE']:
        args.update({'autotest':'否'})
        comm_args.update({'autotest':'否'})

    #通用用例匹配
    comm_args.update({'vultag':'all','phrase':phrase})
    comm_r,comm_tclist = DB().confuse_select_by_kwargs(static_table ,**comm_args)
    if comm_tclist is not None:
        port = ''
        insert_result_info(protol,port,phrase,comm_tclist,param_config,**task_data)
    #条件用例匹配
    for k,v in cpeinfo.items():
        if k == 'HostScan':
            port = ''
            args.update({'vultag':v['os'],'phrase':phrase})
            r,tc_list = DB().confuse_select_by_kwargs(static_table ,**args)
            if tc_list is None:
                continue
            else:
                insert_result_info(protol,port,phrase,tc_list,param_config,**task_data)
        elif k == 'TcpScan' or k == 'UdpScan':
            for echo_port in v :            #每个节点状态进行分析
                data = echo_port
                port = data['port']
                if data['state'].lower() == 'open':  #端口开放时进行用例匹配
                    service = data['service']
                    protol = service
                    if service == 'https' :
                        service = 'tls'
                    elif service == 'http-proxy':
                        service = 'http'
                    args.update({'vultag':service,'phrase':phrase})
                    r,tc_list = DB().confuse_select_by_kwargs(static_table ,**args)   #用例匹配
                    if tc_list is None:
                        continue
                    else:
                        insert_result_info(protol,port,phrase,tc_list,param_config,**task_data)
                else:
                    continue
        else:
            continue
            #print(other)

#def match_pubvuldb_by_cpeinfo(pentask_id,phrase,cpeinfo):
#    if phrase == 'Publicvul':
#        table = config.THREAT_TABLE
#    elif phrase == "Event":
#        table == config.EVENTTESTCASE_TABLE
#    else:
#        table == config.CAPEC_TABLE
#    f = codecs.open(config.TCPARAM_PATH,'r','utf-8')
#    param_config = yaml.safe_load(f)    #获取用例参数配置文件信息
#    f.close()
#
#    table = 't_info_'+pentask_id+'_result'
#    task_args = {'pttask_id':{'data':pentask_id}}
#    r,result = r,result = DB().select_by_kwargs(config.TASKSTATUS_TABLE,**task_args)
#    task_data = result[0][0]
#    protol = ''
#
#    for k,v in cpeinfo.items():
#        if k == 'HostScan':
#            port = ''
#            args = {'vultag':v['os']}
#            #args = {'vultag':"{"+v['os']+"}"}
#            #r,tc_list = DB().select_by_kwargs(table,**args)
#            r,tc_list = DB().confuse_select_by_kwargs(table,**args)
#            if tc_list is None:
#                continue
#            else:
#                insert_result_info(protol,port,phrase,tc_list,param_config,**task_data)
#        elif k == 'TcpScan' or k == 'UdpScan':
#            for echo_port in v :            #每个节点状态进行分析
#                data = echo_port
#                port = data['port']
#                if data['state'].lower() == 'open':  #端口开放时进行用例匹配
#                    service = data['service']
#                    protol = service
#                    if service == 'https' :
#                        service = 'tls'
#                    args = {'vultag':service}
#                    #r,tc_list = DB().select_by_phrase_flag(config.THREAT_TABLE ,**args)   #用例匹配
#                    #r,tc_list = DB().select_by_kwargs(config.THREAT_TABLE,**args)
#                    r,tc_list = DB().confuse_select_by_kwargs(table,**args)
#                    if tc_list is None:
#                        continue
#                    else:
#                        insert_result_info(protol,port,phrase,tc_list,param_config,**task_data)
#                else:
#                    continue
#        else:
#            continue
#            print(other)
#




def insert_testcase_by_phrase(result_table,phrase_list,cur_phrase):
    tcinfo = {}
    for pre_phrase in phrase_list:
        phrase_args = {'phrase':{'data':pre_phrase}}
        r,result = DB().select_by_kwargs(result_table,**phrase_args)
        if result is None:
            continue                    
        for ret in result:
            tmp = ret[2]['result']
            if len(tmp) == 0:
    #            continue
                return None
            else:
                tcinfo.update({ret[0]:tmp['test_result']})
    return tcinfo

def select_tc_from_db(flag):
    r,res = DB().select_tc_by_flag(flag)
    return res


def send_toollibs_cmd(pentask_id, tcname, aws, args_list):
    data = {}
    for args in args_list:
        data.update(args['args'])
    port = ''
    table = "t_info_"+pentask_id+"_result"
    if 'port' in data:
        port = data['port']
    kwargs = {'entcname':tcname,'port':port}
    r,result = DB().select_by_kwargs(table, **kwargs)
    if result is None or (r is False):
        return  config.RESULT_NOT_EXITS,'Result not exist'
    pre_celery_id = result[0][2]['celerytask_id']
    pre_result = result[0][2]['result']
    if pre_celery_id !='' and pre_result == '':
        return pre_celery_id,port
    elif result != '':
        init_args1 = {'celerytask_id':{'data':''}}
        init_args2 = {'result':{'data':''}}
        init_r1,init_result1 = DB().update_by_id_args(table,kwargs,  **init_args1)
        init_r2,init_result2 = DB().update_by_id_args(table,kwargs,  **init_args2)
    kali = {'ip':args['args']['host']}
    r,celery_queue = DB().select_by_kwargs(config.KALI_TABLE, **kali)
    if celery_queue is None or (r is False):
        return  config.RESULT_NOT_EXITS,'Result not exist'
    if len(args_list) >1:
        sig = chain(run_fuction.si(aws,args_list[i]) for i in range(len(args_list)))
    else:
        sig = run_fuction.s(aws,args_list[0])
    r=sig.apply_async(queue = celery_queue[0][0])
    celery_args = {'celerytask_id':{'data':str(r)}}
    data_args = {'args':{'data':data}}
    res1,ret = DB().update_by_id_args(table,kwargs,  **celery_args)
    res2,ret = DB().update_by_id_args(table,kwargs, **data_args)
    return r,port

    

def update_db_result(table,tcname,port,**kwargs):
    condition = {'entcname':tcname,'port':port}
    
    update_data = {'result':{'data':kwargs['result']}}
    r,ret = DB().update_by_id_args(table,condition,**update_data)

def get_tc_result(pentask_id,tcname,port):
    table = "t_info_" + pentask_id + "_result"
    kwargs = {'entcname':tcname,'port':port}
    r,result = DB().select_by_kwargs(table, **kwargs)
    #print(result[0][2])
    if result is None:
        return  {'code':config.RESULT_NOT_EXITS,'message':'Result not exist'}
    else:
        celery_id = result[0][2]['celerytask_id']
        fina_result = result[0][2]['result']
        #print(celery_id,fina_result)
        status =  map_tc_result(celery_id,fina_result)
        
        return {"code":config.LOGIN_OK,"data":{"result":fina_result,"status":status}}

def map_tc_result(celery_id,result):
    status = ''
    if celery_id == '':
        status = config.TASK_NOSTART
    elif result != '':
        status = config.TASK_COMPLETE
    else:
        status = config.TASK_RUNNING
    return status

def insert_result_info(protol,port,phrase,tcinfo,param_config,**data):
    #print(phrase)
    pttask_id = data['pttask_id']
    result_table = 't_info_'+pttask_id+'_result'
    name_map = {'CVE':16,'Publicvul':18,'Event':7}
    steps_map = {'CVE':13,'Publicvul':15,'Event':5}
    resol_map = {'CVE':15,'Publicvul':16,'Event':9}
    #flag_map = {'CVE':{'cveid':2,'componentname':0},'Publicvul':{'vulname':0},'Event':{'testid':7}}
    flag_map = {'CVE':[0,2],'Publicvul':[0,1],'Event':[1]}
    for tc in tcinfo:
        args = {}
        entcname = ''
            
        if phrase != 'Event' and phrase != 'Publicvul' and phrase != 'CVE':
            entcname = tc[0]
            args.update({'tcname':tc[1]})
            params = param_config.get(entcname)
            if port != '':           #用例是否对应特定端口,port端口不为空代表用例适配指定端口
                args.update({'port':port})
            for param in params:
                if param == 'Fullport':
                    scanport = '1-65535'
                    if entcname == 'UdpScan':
                        if data['scanport'] == 'default':
                            scanport = config.DEFAULT_PORT
                        elif data['scanport'] != 'all':
                            scanport = config.DEFAULT_PORT + ','+data['scanport']
                    args.update({'port':scanport})
                elif param == 'ip':
                    args.update({'ip':data['testip']})
                elif param =='host':
                    args.update({'host':data['kali_ip']})
                elif 'name' in param:
                    args.update({'username':data[param]})
                elif 'password' in param:
                    args.update({'password':data[param]})
                elif param == 'time':
                    args.update({'time':str(config.DOS_TIME)})
                elif param == 'protol':
                    args.update({'protol':protol})
                elif param == 'wait_time':
                    args.update({'wait_time':str(config.WAIT_TIME)})
                elif param == 'localpath':
                    args.update({'localpath':config.FIREWARE_PATH})
                elif param == 'remotepath':
                    args.update({'remotepath':config.FILE_PATH})
                elif param == 'connections':
                    args.update({'connections':config.CONNECTIONS})
                elif param=='header':
                    args.update({'header': config.DEFAULT_HEADER})
                else:
                    continue
        else:
            #name_indexlist = name_map[phrase]
            #for name_index in name_indexlist:
            #    entcname += tc[name_index]
            name_index = name_map[phrase]
            steps_index = steps_map[phrase]
            resol_index = resol_map[phrase]
            entcname = tc[name_index]
            #args.update({'tcname':tcname})
            steps = tc[steps_index].replace('"','\"').replace("'","\'")
            resol = tc[resol_index].replace('"','\"').replace("'","\'")
            #for k,v in flag_map[phrase].items():
            #    args.update({k:tc[v]})
            #tcnamelist[i] = tc[i] for i in range(flag_map[phrase]):
            tcnamelist = []
            for i in flag_map[phrase]:
                tcnamelist.append(tc[i])
            tcname = '_'.join(tcnamelist)
            
                
            
            args.update({'attackmethod':steps,'resol':resol,'tcname':tcname})
            #print(args) 
            if port != '':
                args.update({'port':port})
            args.update({'ip':data['testip'],'host':data['kali_ip']})
        arg = {entcname:args}
        DB().insert_result_db(result_table,port,phrase,**arg)   #插入数据库
       
def get_taskid_by_cookie(username):
    args = {'tester':{'data':username},'teststatus':{'data':config.TASK_RUNNING}}
    r,result = DB().select_by_kwargs(config.TASKSTATUS_TABLE, **args)
    if r :
        if result is not None:
            return result[0][0]['pttask_id']
    else: 
        return None

def access_required():
    def decorator(fun):
        def wrapper(*funargs,**funkwargs):
            username = session.get("SID")
            if username is None:
                return {"code":config.LOGIN_FAILD,"data":{"message":"Login faile"}}
            return fun(*funargs,**funkwargs)
        return wrapper
    return decorator

def deldata(table,**kwargs):
    del_r ,del_result = DB().delete_by_id(table,**kwargs)
    if del_r:
        return {"code":config.LOGIN_OK,"data":{"message":"success"}}
    else:
        return {"code":config.SERVER_EXCEPTION,"data":{"message":str(del_result)}}

def generatereport(pttask_id):
    _backgroundMap = {'critical':'#74200f', 'high':'#d43f3a', 'medium':'#fdc431', 'low':'#3fae49', 'bestpractice':'#33ccff','info':'#000077'}
    path = config.REPORTTEMPLATE_PATH
    vuls = []
    Bestpractices = []
    task = {}
    levelCount = {'low':0,'medium':0,'high':0,'critical':0,'bestpractice':0,'info':0}
    levelMap = {'critical':'6','high':'5','medium':'4','low':'3','info':'2','bestpractice':'1'}
    result_table = "t_info_"+pttask_id+"_result"
    status_args = {'pttask_id':{'data':pttask_id}}
    #id_map = {'CVE':['componentname','cveid'],'Publicvul':['vulsource'],'Event':['testid'],'Attack':['testid'],'ServiceScan':['testid'],'HostScan':['testid'],'WebvulScan':['testid'],'SystemvilScan':['testid']}
    table_map = {'CVE':config.CVE_TABLE,'Publicvul':config.THREAT_TABLE,'Event':config.EVENTTESTCASE_TABLE,'Attack':config.TESTCASE_TABLE,'ServiceScan':config.TESTCASE_TABLE,'HostScan':config.TESTCASE_TABLE,'WebvulScan':config.TESTCASE_TABLE,'SystemvilScan':config.TESTCASE_TABLE}
    #pglevel_map = {'CVE':'cvss','Publicvul':'vulgrade','Event':'risklevel','Attack':'risklevel','ServiceScan':'risklevel','HostScan':'risklevel','WebvulScan':'risklevel','SystemvilScan':'risklevel'}
    result_args = {}
    status_r,status_result = DB().select_by_kwargs(config.TASKSTATUS_TABLE,**status_args)
    result_r,result = DB().select_by_kwargs(result_table,**result_args)
    if status_r and result_r:
        task_info = status_result[0][0]
        taskname = task_info['taskname']
        starttime = task_info['starttime']
        endtime = task_info['endtime']
        version = task_info['software']
        ip = task_info['testip']
        tester = task_info['tester']
        task = {'taskName':taskname,'startTime':starttime,'endTime':endtime,'version':version,'ip':ip,'tester':tester}
        for single_result in result:
            if single_result[2]['result'] == '':
                continue
            #entcname = single_result[0]
            entcname = single_result[2]['tcname']
            test_result = single_result[2]['result']['test_result']
            port = single_result[1]
            phrase = single_result[2]['phrase']
            testcase_args = {'vulname':{'testid':single_result[0]},'name':'attackmethod,resol,cvss,vuldetail,vultype,vulgrade,testid'}
            if phrase not in ['Event','Publicvul','CVE']:
                testcase_args['vulname'] = {'vulname':single_result[0]}


            #testcase_args = {'vulname':entcname,'name':'attackmethod,resol,cvss,vuldetail,vultype,vulgrade,'+','.join(id_map[phrase])}
            testcase_r,testcase_result = DB().select_vulinfo_by_phrase(table_map[phrase],**testcase_args)
            testcase_info = testcase_result[0]
            if phrase in ['CVE','Publicvul','Event']:
                steps = str(single_result[2]['attackmethod']).replace('<','%3c').replace('>','%3e')
                solution = single_result[2]['resol'].replace('<','%3c').replace('>','%3e')
            else:
                steps = str(testcase_info[0]).replace('<','%3c').replace('>','%3e')
                solution = testcase_info[1].replace('<','%3c').replace('>','%3e')
            threat_category = testcase_info[4]
            description = testcase_info[3].replace('<','%3c').replace('>','%3e')
            
            if port == '':
                testid = str(testcase_info[6])
            else:
                testid = str(testcase_info[6])+'_'+str(port)
            cve_id = testcase_info[2]
            if test_result == 'Testcase finish,result is NOK' or test_result == 'Failed' or test_result == '失败':
                level = testcase_info[5].lower()
                background = _backgroundMap[level]
                risk_points = levelCount[level]
                levelCount[level] += 1
                single_vul = {'id':testid,'name':entcname,'level':levelMap[level]+level,'port':port,'threat_category':threat_category,'description':description,'solution':solution,'cve_id':cve_id,'background':background,'attackmethod':steps}
                vuls.append(single_vul)
            else:
                level = 'Bestpractice'.lower()
                background = _backgroundMap[level]
                risk_points = levelCount[level]
                levelCount[level] += 1
                practice_vul = {'id':testid,'name':entcname,'level':level,'port':port,'threat_category':threat_category,'description':description,'solution':solution,'cve_id':cve_id,'background':background,'steps':steps}
                Bestpractices.append(practice_vul)
    return vuls,Bestpractices,levelCount,task

def metric_data(failed_list):
    
    testcase_flag_count,testcase_type_count = init_dynamic_data(failed_list,'Attack')
    testcase_type_count['信息收集'] = 0
    testcase_flag_count['all'] = 0
    #print(testcase_flag_count)
    event_flag_count,event_type_count = init_dynamic_data(failed_list,'Event')
    publicevent_flag_count,publicevent_type_count = init_dynamic_data(failed_list,'Publicvul')
    cve_flag_count,cve_type_count  = init_dynamic_data(failed_list,'CVE')
    testcase_num = event_num = publicevent_num = cve_num = 0
    
        

    for failed_case in failed_list:

        phrase = failed_case['phrase']
        vultag = failed_case['vultag']
        vultype = failed_case['vultype']
        if 'http' in vultag:
            vultag = 'http'
            if  phrase == 'Event':
                event_flag_count[vultag] += 1
            elif phrase == 'Publicvul':
                publicevent_flag_count[vultag] += 1
            elif phrase == 'CVE':
                cve_flag_count[vultag] += 1
            else:
                testcase_flag_count[vultag] += 1
        else:
            vultag_list = vultag.split(',')
            for vultag_single in vultag_list:
                if  phrase == 'Event':          
                    event_flag_count[vultag_single] += 1
                elif phrase == 'Publicvul':
                    publicevent_flag_count[vultag_single] += 1
                elif phrase == 'CVE':
                    cve_flag_count[vultag_single] += 1
                else:
                    testcase_flag_count[vultag_single] += 1
        if phrase == 'Event':
            event_type_count[vultype] += 1
            event_num += 1
        elif phrase == 'Publicvul':
            publicevent_type_count[vultype] += 1
            publicevent_num += 1
        elif phrase == 'CVE':
            cve_type_count[vultype] += 1
            cve_num += 1
        else:
            testcase_type_count[vultype] += 1
            testcase_num += 1
    return {'testcase':{'testcase_count':testcase_num,'testcaseflag':testcase_flag_count,'testcasetype':testcase_type_count},'event':{'event_count':event_num,'eventflag':event_flag_count,'eventtype':event_type_count},'public':{'public_count':publicevent_num,'publicflag':publicevent_flag_count,'publictype':publicevent_type_count},'cve':{'cve_count':cve_num,'cveflag':cve_flag_count,'cvetype':cve_type_count}}

            
def dynamic_data_get(status_result):
    total_task = len(status_result)
    pass_task = failed_task = total_case = total_pass_case = total_failed_case = total_testcase_failed = total_event_failed = total_public_failed = total_cve_failed = 0
        
    testcase_tag = {}
    event_tag = {}
    public_tag = {}
    cve_tag = {}
        
    total_testcase_tag,total_testcase_type,total_event_tag,total_event_type, total_public_tag,total_public_type,total_cve_tag,total_cve_type = init_result_data(status_result)

    dynamic_data = {}
    task_data = {}
    fix_data = {}
    for task_single in status_result:
        task = task_single[0]
        total_case += task['result']['detail']['total']
        total_pass_case +=  task['result']['detail']['pass']
        total_failed_case +=  task['result']['detail']['failed']

        if task['result']['task_result'] == config.TASK_OK :
            pass_task += 1
        else:
            failed_task += 1
            total_testcase_failed += task['result']['detail']['testcase']['testcase_count']
            total_cve_failed += task['result']['detail']['cve']['cve_count']
            total_event_failed += task['result']['detail']['event']['event_count']
            total_public_failed += task['result']['detail']['public']['public_count']
            for i in list(total_testcase_tag.keys()):
                if i in task['result']['detail']['testcase']['testcaseflag']:
                    total_testcase_tag[i] += task['result']['detail']['testcase']['testcaseflag'][i]
                else:
                    continue
            for i in list(total_event_tag.keys()):
                if i in task['result']['detail']['event']['eventflag']:
                    total_event_tag[i] += task['result']['detail']['event']['eventflag'][i]
                else:
                    continue
            for i in list(total_public_tag.keys()):
                if i in task['result']['detail']['public']['publicflag']:
                    total_public_tag[i] += task['result']['detail']['public']['publicflag'][i]
                else:
                    continue
            for i in list(total_cve_tag.keys()):
                if i in task['result']['detail']['cve']['cveflag']:
                    total_cve_tag[i] += task['result']['detail']['cve']['cveflag'][i]
                else:
                    continue

            for j in list(total_testcase_type.keys()):
                if j in task['result']['detail']['testcase']['testcasetype']:
                    total_testcase_type[j] += task['result']['detail']['testcase']['testcasetype'][j]
                else:
                    continue
            for j in list(total_event_type.keys()):
                if j in task['result']['detail']['event']['eventtype']:
                    total_event_type[j] += task['result']['detail']['event']['eventtype'][j]
                else:
                    continue
            for j in list(total_public_type.keys()):
                if j in task['result']['detail']['public']['publictype']:
                    total_public_type[j] += task['result']['detail']['public']['publictype'][j]
                else:
                    continue
            for j in list(total_cve_type.keys()):
                if j in task['result']['detail']['cve']['cvetype']:
                    total_cve_type[j] += task['result']['detail']['cve']['cvetype'][j]
                else:
                    continue



    
    failed_data = {'total':total_failed_case,'attack':{'total':total_testcase_failed,'vultag':total_testcase_tag,'vultype':total_testcase_type},'publicvulnerability':{'total':total_public_failed,'vultag':total_public_tag,'vultype':total_public_type},'cve':{'total':total_cve_failed,'vultag':total_cve_tag,'vultype':total_cve_type},'securityevent':{'total':total_event_failed,'vultag':total_event_tag,'vultype':total_event_type}}
    dynmaic = {'task':{'total':total_task,'Pass':pass_task,'failed':failed_task},'testcase':{'total':total_case,'Pass':total_pass_case,'failed':failed_data}}
    return dynmaic

def init_result_data(status_result):
    testcase_tag={}
    testcase_type = {}
    event_tag = {}
    event_type = {}
    public_tag = {}
    public_type = {}
    cve_tag = {}
    cve_type = {}
    for single in status_result:
        task = single[0]['result']['detail']
        testcase_tag.update(task['testcase']['testcaseflag'])
        testcase_type.update(task['testcase']['testcasetype'])
        event_tag.update(task['event']['eventflag'])
        event_type.update(task['event']['eventtype'])
        public_tag.update(task['public']['publicflag'])
        public_type.update(task['public']['publictype'])
        cve_tag.update(task['cve']['cveflag'])
        cve_type.update(task['cve']['cvetype'])
    testcase_tag_count,testcase_type_count = init_list(testcase_tag,testcase_type) 
    event_tag_count,event_type_count = init_list(event_tag,event_type)
    public_tag_count,public_type_count = init_list(public_tag,public_type)
    cve_tag_count,cve_type_count = init_list(cve_tag,cve_type)
    return testcase_tag_count,testcase_type_count,event_tag_count,event_type_count,public_tag_count,public_type_count,cve_tag_count,cve_type_count
    
    
def init_list(tag_dic,type_dic):
    tag_count = {}
    type_count = {}
    tag_list = list(tag_dic.keys())
    type_list = list(type_dic.keys())
    for i in tag_list:
       tag_count[i] = 0
    for j in type_list:
        type_count[j] = 0
    return tag_count,type_count

def case_info_get(table):
    args = {}
    total = 0
    total_tag,total_type = init_vultag_data(table)
    #total_type = init_vultype_data(table)
    args = {'name':'vultag,vultype'}
    r,result = DB().select_vulinfo_by_phrase(table,**args)
    
    for single_result in result:
        vultag = single_result[0]
        vultype = single_result[1]
        if (vultag == '') or (vultag is None):
            continue
        else:
            vultag = vultag.lower()
            total += 1
            if 'http' in vultag:
                vultag = 'http'
                total_tag[vultag] += 1
            else:
                tmp = vultag.strip('}').strip('{').split(',')
                for single_vultag in tmp:
                    total_tag[single_vultag] += 1

            total_type[vultype] += 1
    return {'total':total,'vultag':total_tag,'vultype':total_type}
        
def static_date_get():
    testcase_data = case_info_get(config.TESTCASE_TABLE)
    event_data = case_info_get(config.EVENTTESTCASE_TABLE)
    public_data = case_info_get(config.THREAT_TABLE)
    cve_data = case_info_get(config.CVE_TABLE)
    total = event_data['total']+public_data['total']+cve_data['total']
    return {'autotest':{'total':testcase_data['total']},'threat':{'total':total,'publicvulnerability':public_data,'attackmode':cve_data,'securityevent':event_data}}


def init_vultag_data(table):
    r,result = DB().select_specinfo_by_table(table,'vultag,vultype')
    final_tag_list = []
    final_tag_data = {}
    final_type_list = []
    final_type_data = {}

    for single in result:
        tag_value = single[0]
        vultype_value = single[1]
        if tag_value is None or tag_value == '':
            continue
        else:
            if 'http' in tag_value.lower():
                final_tag_list.append('http')
                
            else:
                tmp = tag_value.strip('{').strip('}').split(',')
                for i in tmp:
                    final_tag_list.append(i.lower())
            final_type_list.append(vultype_value)
    final_tag_list = list(set(final_tag_list))
    final_type_list = list(set(final_type_list))
    for tag_data in final_tag_list:
        final_tag_data[tag_data] = 0
    for type_data in final_type_list:
        final_type_data[type_data] = 0

    return final_tag_data,final_type_data

def init_dynamic_data(failed_list,phrase):
    tag_list = []
    type_list = []
    tag_dic = {}
    type_dic = {}
    for case in failed_list:
        if case['phrase'] == phrase:
            vultag = case['vultag']
            if 'http' in vultag:
                vultag = 'http'
            tag_list.append(vultag)
            type_list.append(case['vultype'])
        else:
            continue
    tag_list = list(set(tag_list))
    type_list = list(set(type_list))
    for i in tag_list:
        tag_dic[i] = 0
    for j in type_list:
        type_dic[j] = 0
    return tag_dic,type_dic


def get_dosresult_from_xml(filepath):
    case_all = {}
    dos_result = []
    dom = minidom.parse(filepath)
    root = dom.documentElement
    versions = root.getElementsByTagName('version')
    for version in versions:
    
        versionname = version.getElementsByTagName('versionname')[0].childNodes[0].data
        productname = version.getElementsByTagName('productname')[0].childNodes[0].data
        tester = version.getElementsByTagName('tester')[0].childNodes[0].data
        testtime = version.getElementsByTagName('testtime')[0].childNodes[0].data
        dosattacktime = version.getElementsByTagName('dosattacktime')[0].childNodes[0].data
        testdt = version.getElementsByTagName('testdt')[0].childNodes[0].data
        case_all.update({'product':productname,'version':versionname,'testtime':testtime,'dosattacktime':dosattacktime,'tester':tester,'testdt':testdt})
    cases = root.getElementsByTagName('case')
    if cases.length != 0:
        for case in cases:
            case_info = {}
            testname = case.getElementsByTagName('testname')[0].childNodes[0].data
            dosrate = case.getElementsByTagName('dosrate')[0].childNodes[0].data
            doscpu = case.getElementsByTagName('doscpu')[0].childNodes[0].data
            dosresult = case.getElementsByTagName('dosresult')[0].childNodes[0].data
            dosreboot = case.getElementsByTagName('dosreboot')[0].childNodes[0].data
            wanipv6pingvalue = case.getElementsByTagName('wanipv6pingvalue')[0].childNodes[0].data
            wanipv4pingvalue = case.getElementsByTagName('wanipv4pingvalue')[0].childNodes[0].data
            lanipv6pingvalue = case.getElementsByTagName('lanipv6pingvalue')[0].childNodes[0].data
            lanipv4pingvalue = case.getElementsByTagName('lanipv4pingvalue')[0].childNodes[0].data
            lanipv4pingdns = case.getElementsByTagName('lanipv4pingdns')[0].childNodes[0].data
            totalmemstart = case.getElementsByTagName('totalmemstart')[0].childNodes[0].data
            totalmemend = case.getElementsByTagName('totalmemend')[0].childNodes[0].data
            freememstart = case.getElementsByTagName('freememstart')[0].childNodes[0].data
            freememend = case.getElementsByTagName('freememend')[0].childNodes[0].data
            freememdifvalue = case.getElementsByTagName('freememdifvalue')[0].childNodes[0].data
            doscmd = case.getElementsByTagName('doscmd')[0].childNodes[0].data
            memcheckvalue = case.getElementsByTagName('memcheckvalue')[0].childNodes[0].data
            pidcheckvalue = case.getElementsByTagName('pidcheckvalue')[0].childNodes[0].data
            case_info.update({"casename":testname,"dosrate":dosrate,"doscpu":doscpu,"dosresult":dosresult,"dosreboot":dosreboot,"wanipv6pingvalue":wanipv6pingvalue,"wanipv4pingvalue":wanipv4pingvalue,"lanipv6pingvalue":lanipv6pingvalue,"lanipv4pingvalue":lanipv4pingvalue,"lanipv4pingdns":lanipv4pingdns,"totalmemstart":totalmemstart,"totalmemend":totalmemend,"freememstart":freememstart,"freememend":freememend,"freememdifvalue":freememdifvalue,"doscmd":doscmd,"memcheckvalue":memcheckvalue,"pidcheckvalue":pidcheckvalue})
            #case_info.update({"casename":testname,"dosrate":dosrate,"doscpu":doscpu,"dosresult":dosresult,"dosreboot":dosreboot,"wanipv6pingvalue":wanipv6pingvalue,"wanipv4pingvalue":wanipv4pingvalue,"lanipv6pingvalue":lanipv6pingvalue,"lanipv4pingvalue":lanipv4pingvalue,"lanipv4pingdns":lanipv4pingdns,"totalmemstart":totalmemstart,"totalmemend":totalmemend,"freememstart":freememstart,"freememend":freememend,"freememdifvalue":freememdifvalue,"memcheckvalue":memcheckvalue,"pidcheckvalue":pidcheckvalue})
            if case.getElementsByTagName('httpdpidvaluestart'):
                httpdpidvaluestart = case.getElementsByTagName('httpdpidvaluestart')[0].childNodes[0].data
                httpdpidvalueend = case.getElementsByTagName('httpdpidvalueend')[0].childNodes[0].data
                httpdhandlestart = case.getElementsByTagName('httpdhandlestart')[0].childNodes[0].data
                httpdhandleend = case.getElementsByTagName('httpdhandleend')[0].childNodes[0].data
                case_info.update({"httpdpidvaluestart":httpdpidvaluestart,"httpdpidvalueend":httpdpidvalueend,"httpdhandlestart":httpdhandlestart,"httpdhandleend":httpdhandleend})
            if case.getElementsByTagName('smbdpidvaluestart'):
                smbdpidvaluestart =  case.getElementsByTagName('smbdpidvaluestart')[0].childNodes[0].data
                smbdpidvalueend =  case.getElementsByTagName('smbdpidvalueend')[0].childNodes[0].data
                case_info.update({"smbdpidvaluestart":smbdpidvaluestart,"smbdpidvalueend":smbdpidvalueend})
            if case.getElementsByTagName('ftpdpidvaluestart'):
                ftpdpidvaluestart =  case.getElementsByTagName('ftpdpidvaluestart')[0].childNodes[0].data
                ftpdpidvalueend =  case.getElementsByTagName('ftpdpidvalueend')[0].childNodes[0].data
                case_info.update({"ftpdpidvaluestart":ftpdpidvaluestart,"ftpdpidvalueend":ftpdpidvalueend})
            if case.getElementsByTagName('dnspidvaluestart'):
                dnspidvaluestart =  case.getElementsByTagName('dnspidvaluestart')[0].childNodes[0].data
                dnspidvalueend =  case.getElementsByTagName('dnspidvalueend')[0].childNodes[0].data
                case_info.update({"dnspidvaluestart":dnspidvaluestart,"dnspidvalueend":dnspidvalueend})

            
            dos_result.append(case_info)
           
    case_all['result'] = json.dumps(dos_result)
    return case_all
            

