# -*- coding:UTF-8 -*-
# UDP
from socket import *
import time
HOST = '255.255.255.255'
PORT = 7788
BUFSIZE = 1024
ADDR = (HOST, PORT)

broadcast = socket(AF_INET, SOCK_DGRAM)
broadcast.setsockopt(SOL_SOCKET, SO_BROADCAST, 1)
while True:
    time.sleep(2)
    broadcast.sendto(b'\x79\x75\x6E\x73\x68\x61\x6E\x67\x2E\x63\x6F\x6D', ADDR)

