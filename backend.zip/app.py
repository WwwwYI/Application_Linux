# -*- coding: utf-8 -*-
from flask import Flask
from flask_cors import CORS
from router import api
from datetime import timedelta



app = Flask(__name__)

app.config['SECRET_KEY'] = 'akjsdhkjashdkjhaksk120191101asd'
app.config['SESSION_REFRESH_EACH_REQUEST'] = True
app.permanent_session_lifetime = timedelta(hours=24)
app.MAX_CONTENT_LENGTH = 100*1024*1024
#CORS(app, supports_credentials=True, resources={r"*": {"origins": "*"}})
CORS(app, resources={r"*": {"origins": "*"}})


api.init_app(app)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=4999)
