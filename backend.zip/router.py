# -*- coding:utf-8 -*-
import flask_restful
from action.CreateScheme import CreateScheme
from action.DoTask import DoTask
from action.GetPlatform import GetPlatform
from action.SetPlatform import SetPlatform
from action.ChangePipGun import ChangePipGun
from action.GetScheme import GetScheme
from action.GetMaterial import GetMaterial
from action.GetPipgun import GetPipgun
from action.GetStatus import GetStatus
from user.Login import Login
from user.Logout import Logout
from user.Info import Info

api = flask_restful.Api(catch_all_404s=True)

# 重新定义flask restful 400错误

api.add_resource(CreateScheme, '/api/v1.0/action/CreateScheme')
api.add_resource(DoTask, '/api/v1.0/action/DoTask')
api.add_resource(GetPlatform, '/api/v1.0/action/GetPlatform')
api.add_resource(SetPlatform, '/api/v1.0/action/SetPlatform')
api.add_resource(ChangePipGun, '/api/v1.0/action/ChangePipGun')
api.add_resource(GetScheme, '/api/v1.0/action/GetScheme')
api.add_resource(GetMaterial, '/api/v1.0/action/GetMaterial')
api.add_resource(GetPipgun, '/api/v1.0/action/GetPipgun')
api.add_resource(GetStatus, '/api/v1.0/action/GetStatus')
api.add_resource(Login, '/api/v1.0/user/Login')
api.add_resource(Logout, '/api/v1.0/user/Logout')
api.add_resource(Info, '/api/v1.0/user/Info')

