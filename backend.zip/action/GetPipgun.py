
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import random
import string
parser = reqparse.RequestParser()
#parser.add_argument('page', type=str, required=True, trim=True)
#parser.add_argument('limit', type=str, required=True, trim=True)
import yaml

import sys
import os
sys.path.append(os.path.abspath("./")) 

from util.HandleLog import HandleLog
log = HandleLog()


class GetPipgun(Resource):
       
    #@access_required()
    def get(self):
        args = parser.parse_args()
        try:
            with open('./config.yaml','r') as f:
                data = yaml.safe_load(f)
        except Exception as e:
            log.error("YAML read Error: %s",e)
        return {"code":20000,"data":{"items":data['PipGunCfg']}}

        
        

