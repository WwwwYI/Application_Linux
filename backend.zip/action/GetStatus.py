
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import random
import string
parser = reqparse.RequestParser()
#parser.add_argument('page', type=str, required=True, trim=True)
#parser.add_argument('limit', type=str, required=True, trim=True)
import yaml

import sys
import os
sys.path.append(os.path.abspath("./")) 
import GlobalVar
from util.HandleLog import HandleLog
log = HandleLog()


class GetStatus(Resource):
       
    #@access_required()
    def get(self):
        args = parser.parse_args()
        return {"code":20000,"data":{"items":GlobalVar.Status}}

        
        

