
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import random
import string
parser = reqparse.RequestParser()
parser.add_argument('RangeLowerLimit', type=str, required=True, trim=True)
parser.add_argument('RangeUpperLimit', type=str, required=True, trim=True)
parser.add_argument('RangeDelta', type=str, required=True, trim=True)
import yaml

import sys
import os
sys.path.append(os.path.abspath("./")) 
import GlobalVar

from util.HandleLog import HandleLog
log = HandleLog()


class ChangePipGun(Resource):
       
    #@access_required()
    def get(self):
        args = parser.parse_args()
        RangeLowerLimit = int(args['RangeLowerLimit'])
        RangeUpperLimit = int(args['RangeUpperLimit'])
        RangeDelta = int(args['RangeDelta'])
        if GlobalVar.Status ==0:
              log.info('change qiang tou')
        else:
           return {"code":20000,"data":{"message":"设备正在运行中，请等待设备工作结束后更换移液枪!"}}
        try:
            with open('./config.yaml','r') as f:
                data = yaml.safe_load(f)
                data['PipGunCfg']['RangeLowerLimit']= RangeLowerLimit
                data['PipGunCfg']['RangeUpperLimit']= RangeUpperLimit
                data['PipGunCfg']['RangeDelta']= RangeDelta
            with open('./config.yaml','w') as f:
                yaml.dump(data,f)
        except Exception as e:
            log.error("YAML read Error: %s",e)
        return {"code":20000,"data":"success"}

        
        

