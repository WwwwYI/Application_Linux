
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import random
import string
parser = reqparse.RequestParser()
parser.add_argument('run', type=int, required=True, trim=True)
import yaml

import sys
import os
sys.path.append(os.path.abspath("./")) 
import GlobalVar
import time
from util.HandleLog import HandleLog
log = HandleLog()


import MotorDriver
from MotorDriver import CDM57_StepMotor

import Pipet

from threading import Thread

def work_task(args):
    GlobalVar.Status =1
    try:
        log.info(args)
        myPipet  = Pipet.CPipLiquid()
        myPipet.ReadCfg()
        myPipet.TransScheme(args[0],args[1],args[2])
        myPipet.ExcuteScheme()
        
        #log.info(args)
        #time.sleep(10)
        GlobalVar.Status =0
    except Exception as e:
        print(e)
    finally:
        log.info('work complete!')
        GlobalVar.Status =0
        return 0


class MyThread(Thread):
    
    def __init__(self,args):
        Thread.__init__(self)
        self.args = args
        
    def run(self):
        self.result = work_task(self.args)
    
    def get_result(self):
        return self.result


class DoTask(Resource):
    #@access_required()
    def get(self):
        args = parser.parse_args()
        run = int(args['run'])
        if run == 1:#多线程运行
            if len(GlobalVar.SchemeArgs) ==3:
                th_run = MyThread(GlobalVar.SchemeArgs)
                th_run.run()
                log.info('running...')
            else:
                return {"code":20000,"data":{"message":"无移液方案，请先配置移液方案"}}
        if run == 0:#停止运行
            log.info('stop...')
            pass
        if run == 2:#替换移液枪
            if GlobalVar.Status ==0:
              log.info('change qiang tou')
            else:
              return {"code":20000,"data":{"message":"设备正在运行中，请等待设备停止后进行更换移液枪"}}
            pass
        return {"code":20000,"data":{"message":"success"}}      
             


if __name__ == "__main__":
    #c=SetPlatform()
    #c.HttpMethodPut(uri="http://192.168.1.1",cpeid=124,username="bbb",pwd="ccc")
    #c.HttpMethodPut(uri="http://192.168.1.1")
    #c.post()
    print('aaa')
