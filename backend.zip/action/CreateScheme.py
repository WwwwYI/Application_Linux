# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import random
import string
import yaml
from itertools import combinations
import numpy as np

parser = reqparse.RequestParser()



import sys
import os
sys.path.append(os.path.abspath("./")) 
import GlobalVar

from util.HandleLog import HandleLog
log = HandleLog()

args={
"测试1":{
"start":300,
"step":10,
"count":1
},
"测试2":{
"start":300,
"step":10,
"count":2
},
"测试3":{
"start":200,
"step":10,
"count":1
},
"测试4":{
"start":500,
"step":10,
"count":1
}

}
'''
[{'ceshi1',300},{'ceshi2',300},{'ceshi2',310},{'ceshi3',100},{'ceshi3',110}]
[('ceshi2',300),('ceshi2',310)]
[('ceshi3',100),('ceshi3',10)]


'''
'''
"items":[{"Number":1,"tube_location":[],"Scheme":()}]
[([1, [1, 1]], [300, 300, 200, 500]), ([1, [1, 2]], [300, 310, 200, 500])]
['测试1', '测试2', '测试3', '测试4']
'''

def _checkscheme(arg):
    r=[]
    try:
        with open('./config.yaml','r',encoding='utf-8') as f:
            data = yaml.safe_load(f)
    except Exception as e:
        log.error("YAML read Error: %s",e)
    _listpipgun=np.arange(data['PipGunCfg']['RangeLowerLimit'],data['PipGunCfg']['RangeUpperLimit']+data['PipGunCfg']['RangeDelta'],data['PipGunCfg']['RangeDelta'])
    log.info(_listpipgun)
    for k,v in arg.items():
        _l = np.arange(v['start'],v['start']+v['step']*v['count'],v['step'])
        tmp_v = list(filter(lambda x:x in _listpipgun,_l))
        log.info(_l)
        if len(tmp_v) != len(_l):
            r.append(k)
    print("check_scheme: ",r)
    return r

def _generate_scheme(arg):
    items=[]
    _lst_arg=[]
    for m,n in zip(arg['args'][1],arg['args'][2]):
        _lst_arg.append((m,n))
    #print('_generate_scheme _lst_arg:',_lst_arg)
    for i in range(len(_lst_arg)):
        _scheme={}
        _scheme['tupelocation']=_lst_arg[i][0]
        _scheme['id'] = i+1
        _tmp_Scheme=[]
        for k,j in zip(arg['material'],_lst_arg[i][1]):
            _tmp_Scheme.append([k,j])
        _scheme['scheme'] = _tmp_Scheme
        items.append(_scheme)
    #print('_generate_scheme items:',items)
    for val in items:
        _st=""
        val['tupelocation']="区域:"+str(val['tupelocation'][0])+"第"+str(val['tupelocation'][1][0])+"行，第"+str(val['tupelocation'][1][1])+"列"
        for _v in val['scheme']:
            _st += _v[0]+": "+str(_v[1])+" ; "
        val['scheme']=_st[:-2]
    #print('_generate_scheme items:',items)
    GlobalVar.SchemeList['items']=items
    log.info(items)
    try:
        with open('./tmpSchemelist.yaml','w',encoding='utf-8') as f:
            yaml.dump(items,f)
    except Exception as e:
        log.error("YAML read Error: %s",e)

def _generate_arg(arg):
    '''
    '''
    try:
        with open('./platform.yaml','r') as f:
            data = yaml.safe_load(f)
            print(data['platform'])
    except Exception as e:
        log.error("YAML read Error: %s",e)
    _args =_get_volumn_arg(arg)
    #_args = [(('First', 200), ('Second', 200), ('Third', 200), ('Fouth', 200))]
    print('_generate_arg _args: ',_args)
    src=[]
    volumn=[]
    dst=[]
    material=[]
    # for j in _args:#初始化volumn
    #     volumn.append([])
    print('_generate_arg volumn: ',volumn)
    for k,v in arg.items():
        cur = []
        print(k)
        material.append(k)
        for i in range(len(data['platform'])):
            if k in data['platform'][i].keys():
                src.append([i+1,data['platform'][i][k]])
        # for j in range(len(_args)):
        #     for _j in _args[j]:
        #         if _j[0] == k:
        #             # volumn[j].append(_j)
        #             volumn[j].append(_j[1])
        for j in range(len(_args)):
            for _j in _args[j]:
                if _j[0] == k:
                    cur.append(_j[1])
        volumn.append(cur)
            # if j[0] == k:
            #     for _item in j:
            #         cur.append(_item[1])
            #     volumn.append(cur)
    print('_generate_arg——src:', src)
    print('_generate_arg——volumn:', volumn)
    print('_generate_arg material: ',material)
    dst=_get_dst_arg(len(volumn[0]))
    GlobalVar.SchemeArgs=[src,dst,volumn]
    log.info(GlobalVar.SchemeArgs)
    return {'args':[src,dst,volumn],'material':material}



def _get_volumn_arg(arg):
    '''
    生成取液体积的参数
    '''
    _arg=[]
    _count=0
    for k,v in arg.items():
        print('k = ',k)
        _lst=np.arange(arg[k]['start'],arg[k]['start']+arg[k]['step']*arg[k]['count'],arg[k]['step'])
        print('_get_volumn_arg: ',_lst)
        for i in _lst:
            _arg.append((k,i))
            print('_arg = ',_arg)
        _count +=1
    _comblist=list(combinations(_arg,_count))
    print('_comblist = ',_comblist)
    #去重
    _args=[]
    for _l in _comblist:
        _tmp_lst=[]
        for i in _l:
            _tmp_lst.append(i[0])
        if len(list(set(_tmp_lst))) == len(_l):
            _args.append(_l)
    print('_get_volumn_arg: ',_args)
    return _args

    # _arg = []
    # for k,v in arg.items():
    #     print('k = ',k)
    #     _lst=np.arange(arg[k]['start'],arg[k]['start']+arg[k]['step']*arg[k]['count'],arg[k]['step'])
    #     _arg.append(_lst)
    # return _arg

        
#print(_get_volumn_arg(args))



def _get_dst_arg(arg):
    #arg = len(volumn)
    '''
    '''
    try:
        with open('./platform.yaml','r') as f:
            data = yaml.safe_load(f)
            #print(data['platform'])
    except Exception as e:
        log.error("YAML read Error: %s",e)
    lst_arg=[]
    for i in range(len(data['platform'])):
        if data['platform'][i] == {}:
            continue
        if data['platform'][i]['type'] == 'tube':
            _lst_tmp=[]
            for j in range(int(data['platform'][i]['row'])*int(data['platform'][i]['column'])):
                _lst_tmp.append(i+1)
            _row=np.arange(1,data['platform'][i]['row']+1)
            _column=np.arange(1,data['platform'][i]['column']+1)
            _lst_location=[[i,j] for i in _row for j in _column]
            print('_get_dst_arg: ',_lst_tmp)
            print('_get_dst_arg:  ',_lst_location)
            #_lst_zip = zip(_lst_tmp,_lst_location)
            for m,n in zip(_lst_tmp,_lst_location):
                lst_arg.append([m,n])
    print('_get_dst_arg: ',lst_arg[:arg])
    return lst_arg[:arg]
            

class CreateScheme(Resource):
    #@access_required()
    def post(self):
        data = json.loads(request.get_data(as_text=True))
        print("Recieve from frontend: ",data)
        if data is not None:
            check_result = _checkscheme(data)
            if len(check_result) != 0:
                msg=""
                for r in check_result:
                    msg += r+","
                return {"code" :20000, "data":{"message":"溶液"+msg+"配比失败，请更换移液枪或重新设计配比方案"}}
            args=_generate_arg(data) #生成方案执行的入参，并存储到 GlobalVar.SchemeArgs
            _generate_scheme(args)#生成方案list，并存储GlobalVar.SchemeList 提供给前端显
            #执行动作
            return {"code":20000,"data":{"message":"success"}}

if __name__ == "__main__":
    c=CreateScheme()
    # c.HttpMethodPut(uri="http://192.168.1.1",cpeid=124,username="bbb",pwd="ccc")
    # c.HttpMethodPut(uri="http://192.168.1.1")
    # c.post()
