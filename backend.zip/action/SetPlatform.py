
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import random
import string
parser = reqparse.RequestParser()
import yaml

import sys
import os
sys.path.append(os.path.abspath("./")) 
import GlobalVar

from util.HandleLog import HandleLog
log = HandleLog()


# data={"platform":[
# {"type":"tube","row":1,"column":6},
# {"type":"material","测试3":[1,1],"测试4":[1,2]},
# {},
# {"type":"material","测试1":[1,1],"测试2":[1,2]},
# {"type":"tube","row":30,"column":2}
# ]
# }

def _set_config(arg):
    try:
        with open('./config.yaml','r') as f:
            data = yaml.safe_load(f)

            tubebox_num = 0
            materialbox_num = 0
            gunheadbox_num = 0
            for i in range(len(arg['platform'])):
                if arg['platform'][i] == {}:
                    continue
                if arg['platform'][i]['type'] == 'tube':
                    tubebox_num += 1
                if arg['platform'][i]['type'] == 'material':
                    materialbox_num += 1
                if arg['platform'][i]['type'] == 'gunhead':
                    gunheadbox_num += 1

            _tubelist = [i for i in range(tubebox_num)]
            _materiallist = [i for i in range(materialbox_num)]
            _gunheadlist = [i for i in range(gunheadbox_num)]
                
                
            for i in range(len(arg['platform'])):
                if arg['platform'][i] == {}:
                    continue
                if arg['platform'][i]['type'] == 'tube':
                    data['Platform']['Container_0'+ str(i+1)]['BoxType'] = 'TubeHolder_0' + str(_tubelist[0] + 1)
                    data['Holder']['TubeHolder_0' + str(_tubelist[0] + 1)]['RowsNum'] = arg['platform'][i]['row']
                    data['Holder']['TubeHolder_0' + str(_tubelist[0] + 1)]['ColumnsNum'] = arg['platform'][i]['column']
                    _tubelist.pop(0)

                if arg['platform'][i]['type'] == 'material':
                    data['Platform']['Container_0'+str(i+1)]['BoxType'] = 'BottleHolder_0' + str(_materiallist[0]+1)
                    data['Holder']['BottleHolder_0' + str(_materiallist[0]+1)]['RowsNum'] = arg['platform'][i]['row']
                    data['Holder']['BottleHolder_0' + str(_materiallist[0]+1)]['ColumnsNum'] = arg['platform'][i]['column']
                    _materiallist.pop(0)

                if arg['platform'][i]['type'] == 'gunhead':
                    data['Platform']['Container_0'+str(i+1)]['BoxType'] = 'GunHeadHolder_0' + str(_gunheadlist[0] + 1)
                    data['Holder']['GunHeadHolder_0' + str(_gunheadlist[0] + 1)]['RowsNum'] = arg['platform'][i]['row']
                    data['Holder']['GunHeadHolder_0' + str(_gunheadlist[0] + 1)]['ColumnsNum'] = arg['platform'][i]['column']
                    _gunheadlist.pop(0)

            # for i in range(len(arg['platform'])):
            #     if arg['platform'][i] == {}:
            #         continue
            #     if arg['platform'][i]['type'] == 'tube':
            #         data['Platform']['Container_0'+str(i+1)]['BoxType'] = 'TubeHolder_01'
            #         data['Holder']['TubeHolder_01']['RowsNum'] = arg['platform'][i]['row']
            #         data['Holder']['TubeHolder_01']['ColumnsNum'] = arg['platform'][i]['column']
            #     if arg['platform'][i]['type'] == 'material':
            #         data['Platform']['Container_0'+str(i+1)]['BoxType'] = 'BottleHolder_01'
            #         data['Holder']['BottleHolder_01']['RowsNum'] = arg['platform'][i]['row']
            #         data['Holder']['BottleHolder_01']['ColumnsNum'] = arg['platform'][i]['column']
            #     if arg['platform'][i]['type'] == 'gunhead':
            #         data['Platform']['Container_0'+str(i+1)]['BoxType'] = 'GunHeadHolder_01'
            #         data['Holder']['GunHeadHolder_01']['RowsNum'] = arg['platform'][i]['row']
            #         data['Holder']['GunHeadHolder_01']['ColumnsNum'] = arg['platform'][i]['column']

        with open('./config.yaml','w') as f:
            yaml.dump(data,f)
    except Exception as e:
        log.error("YAML read Error: %s",e)


class SetPlatform(Resource):
    #@access_required()
    def post(self):
        data = json.loads(request.get_data(as_text=True))
        log.info(data)
        if data is not None:
            with open('./platform.yaml','w',encoding='utf-8') as f:
                yaml.dump(data,f)
            _set_config(data)
            return {"code":20000,"data":{"message":"success"}}      


             



if __name__ == "__main__":
    c=SetPlatform()
    #c.HttpMethodPut(uri="http://192.168.1.1",cpeid=124,username="bbb",pwd="ccc")
    #c.HttpMethodPut(uri="http://192.168.1.1")
    c.post()