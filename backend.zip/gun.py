#!/usr/bin/python
# coding:utf-8
import multiprocessing

bind = '0.0.0.0:4999'
workers = multiprocessing.cpu_count() * 2 + 1
workers = 1

backlog = 2048
#  pip install gevent
worker_class = "gevent"
loglevel = 'error'
accesslog = '/var/log/gunicorn/access.log'
errorlog = '/var/log/gunicorn/error.log'
capture_output = False
