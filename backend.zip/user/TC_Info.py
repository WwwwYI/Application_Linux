# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,redirect,session
import json
import common.constconfig as config
from common.db import DB
from util.utility import *

parser = reqparse.RequestParser()
parser.add_argument('pentask_id', type=str, trim=True)
parser.add_argument('phrase', type=str, trim=True)


class TC_Info(Resource):
    def get(self):
        arg = parser.parse_args()
        pentask_id = str(arg['pentask_id'])
        phrase = arg['phrase']
        
        tc_table = 't_info_testcase'
        result_table = 't_info_'+pentask_id+'_result'
        phrase_args = {'phrase':{'data':phrase}}
        r,result = DB().select_by_kwargs(result_table,**phrase_args)
        fina_result = []
        for echo in result:
            tcname = echo[0]
            port = echo[1]
            args = echo[2]['args']
            print(args)
            celery_id = echo[2]['celerytask_id']
            tc_result = echo[2]['result']
            state = map_tc_result(celery_id,tc_result)['state']
            single_result = {'tcname':tcname,'port':port,'args':args,'state':state}
            fina_result.append(single_result)
        return fina_result
