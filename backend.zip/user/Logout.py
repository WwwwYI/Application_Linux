
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import common.constconfig as config
import random
import string

parser = reqparse.RequestParser()



class Logout(Resource):
    def post(self):
        return {"code":config.LOGIN_OK,"data":{
                "message":"success"
               }}
        
        

