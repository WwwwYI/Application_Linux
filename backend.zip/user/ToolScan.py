# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,redirect,session
import json
import common.constconfig as config
from common.db import DB
import time
from util.utility import *


parser = reqparse.RequestParser()
parser.add_argument('pentask_id', type=str, trim=True)
'''函数功能说明

        通过get接口查看工具扫描用例信息

        Args:
            get消息URL中包含pentask_id信息，根据pentask_id信息查询相关任务结果表中ServiceScan结果信息

        Returns:
            1. code=200,表示执行机当前状态空闲，可创建执行任务
            2. code=401,表示执行机地址错误或执行机忙，不可创建任务

        通过post接口创建执行任务

        Args:
            输入参数为json格式,URL中包含空闲的kali_ip信息
            
            创建执行任务需完成操作有
            1、创建任务ID
            2、更新环境表信息，将任务ID跟新到对应执行机记录中
            3、创建任务结果表，任务表名包含任务ID信息
            4、任务信息插入任务状态表
            5、将阶段为ServiceScan用例记录插入任务结果表

        Returns:
            1. pttask_id:任务ID
'''


class ToolScan(Resource):
    def get(self):
        args = parser.parse_args()
        pentask_id = str(args['pentask_id'])
        #servicescan_phrase = 'ServiceScan'
        phrase = {'phrase':{'data':'ServiceScan'}}
        table = "t_info_" + pentask_id + "_result"
        r,result = DB().select_by_kwargs(table,**phrase)
        #print(result)
        tcinfo = {}
        for ret in result:
            tmp = ret[2]['result']
            if len(tmp) == 0:
                return {"message":"Information do not over,please wait"}
            else:
                #print(tmp,type(tmp))
                tcinfo.update({ret[0]:tmp['test_result']})
               # continue
        print(tcinfo)
        match_db_by_cpeinfo(pentask_id,'ToolScan',tcinfo)
        #print(tcinfo)
#        os = get_cpe_information(table,self.HostScan)
#        match_db_by_cpeinfo(table,os)


        #args = {'ip':kali_ip}
        #r,result = DB().select_by_kwargs(config.KALI_TABLE,**args)
        
        #if result is None:
         #   return {"code":config.PTTASK_NOT_EXITS,"message":"Kali_ip input error,please try again"}
        #pentask_id = result[0][1]
        #if pentask_id == "":
         #   return {"code":config.LOGIN_OK,"message":"Kali is free, Please create your task."}
        #task_args = {'pttask_id':{'data':str(pentask_id)}}
        #r,result = DB().select_by_kwargs(config.TASKSTATUS_TABLE,**task_args)
        #print(result)
        
        #if result is None or result[0][0]['pttask_status'] != 'RUNNING' :
            
         #   return {"code":config.LOGIN_OK,"message":"Kali is free, Please create your task."}
        #else:
        #    return {"code":config.PTTASK_NOT_EXITS,"message":"Kali is busy,please wait or try another kali"}
       
    def post(self):
        args = parser.parse_args()
        kali_ip = str(args['kali_ip'])
        data = json.loads(request.get_data(as_text=True))
        t = time.time()
        #pttask_id = round(t * 1000)
        pttask_id = 1623224784392
        pentask_args = {}
        data.update({'pttask_id':str(pttask_id),'kali_ip':kali_ip})
        r,result = DB().insert(config.TASKSTATUS_TABLE,data)
        conditions = {'ip':kali_ip}
        kali_args = {'pttask_id':str(pttask_id)}
        r,result = DB().update_by_id_args(config.KALI_TABLE,conditions,**kali_args)
        #r, result = DB().create_table(str(pttask_id))
        phrase_args = {'phrase':'ServiceScan'}
        r,result = DB().select_by_kwargs(config.TESTCASE_TABLE,**phrase_args)
        print(result)
        
        insert_result_info('ServiceScan',result,**data)        
        return {"code":config.LOGIN_OK,"pttask_id":pttask_id}
