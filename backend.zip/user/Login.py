
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import common.constconfig as config
import random
import string

parser = reqparse.RequestParser()



class Login(Resource):
    def post(self):
        arg = parser.parse_args()
        data = json.loads(request.get_data(as_text=True))
        return {"code":20000,"data":{
                "token":"admin-token"
               }}
        
        

