
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
from common.db import DB
import common.constconfig as config
import random
import string
from util.utility import *
parser = reqparse.RequestParser()



class Adduser(Resource):
    @access_required()
    def post(self):
        data = json.loads(request.get_data(as_text=True))
        password = data['password']
        username = data['username']
        acc_args = {'job_id':{'data':username}} 
        acc_r,acc_result = DB().select_by_kwargs(config.ACCOUNT_TABLE,**acc_args) 
        if acc_result is not None:
            args = {'password':{'data':password}}
            r,result = DB().update_by_id_args(config.ACCOUNT_TABLE,acc_args,**args)
            if r:
                return {"code":config.LOGIN_OK,"data":{"message":"change password success"}}      
        else:
            data.update({'job_id':username,'token':'','name':'','avatar':'','introduction':''})
            print(data)
            r,result = DB().insert(config.ACCOUNT_TABLE,data)
            if r:
                return {"code":config.LOGIN_OK,"data":{"message":"add user success"}}
        return {"code":config.SERVER_EXCEPTION,"data":{"message":str(result)}}


             

