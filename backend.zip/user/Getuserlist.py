
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
from common.db import DB
import common.constconfig as config
import random
import string
from util.utility import *
parser = reqparse.RequestParser()
parser.add_argument('page', type=str, required=True, trim=True)
parser.add_argument('limit', type=str, required=True, trim=True)



class Getuserlist(Resource):
       
    @access_required()
    def get(self):
        args = parser.parse_args()
        page = int(args['page'])
        limit = int(args['limit'])
        start = (page-1)*limit
        args = {}
        result_data = []
        count_r,count_result = DB().select_count_by_kwargs(config.ACCOUNT_TABLE,**args)
        if int(count_result[0][0]) == 0:
            return {"code":config.LOGIN_OK,"data":{"total":len(result_data),"items":result_data}}
        r,result = DB().select_by_kwargs(config.ACCOUNT_TABLE,start=start,offset=limit,**args)
        if r:
            if result is not None:
                for i in range(0,len(result)):
                    tmp = result[i]
                    result_data.append({"id":i+1,"username":tmp[0]['job_id'],"right":tmp[0]['right'],"userdescription":tmp[0]['introduction']})
            return {"code":config.LOGIN_OK,"data":{"total":int(count_result[0][0]),"items":result_data}}
        return {"code":config.SERVER_EXCEPTION,"data":{"message":str(result)}}

        
        

