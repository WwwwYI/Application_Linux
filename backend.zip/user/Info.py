
# -*- coding: utf-8 -*-
from flask_restful import Resource, reqparse
from flask import request,session
import json
import common.constconfig as config
import random
import string

parser = reqparse.RequestParser()
#parser.add_argument('token', type=str, trim=True)



class Info(Resource):
       
    def get(self):
        arg = parser.parse_args()
        return {"code":config.LOGIN_OK,"data":{"roles":["admin"],"name":"admin","introduction":"admin","avatar":""}}
        
        

