#coding=utf8
SchemeArgs=[]
SchemeList={}
Status=0 #状态  0表示停止中，1表示运行中，2表示替换枪中