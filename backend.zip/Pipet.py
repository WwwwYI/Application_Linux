import MotorDriver
import time
import datetime
import yaml
import os



# 试剂瓶的位置 [[1,1] ,[3,4]] , [[1,1] ,[3,4]] , [[1,1] ,[3,4]]
# 试管的位置 [[2,1], [5,0] ] [ [2,1] , [5,1] ]
# 反应所需的溶液体积 [[200,175],[380,390],[100,110]]
# 用二维数组表示移液方案
# 试剂瓶位置 第一行第二列盒子中，第三行，第四列 的瓶位的瓶子
# 试管位置 第一行第二列盒子中，第三行，第四列 的瓶位的试管
# 溶液体积是 第一个试剂瓶中 取200 进入第一个试管，取175，进入第二个试管，这个数组，列数对应试管，行数对应试剂瓶

XAxisAddr = 1
YAxisAddr = 2
ZAxisAddr = 3

KnobMoAddr = 4
PressMoAddr = 5
ReactMoAddr = 6


ResetVi = 7.2
ZAxisOrigin = 250

# GunHeadAxis_Px_Orign = 5
# GunHeadAxis_Py_Orign = 5
# GunHeadAxis_Heaght  = 70
# GunHeadContainer_X = 100
# GunHeadContainer_Y = 100
# GunHeadNextSerial = 1

class AxisState:
    def __init__(self, curP, aimP, vi, addr):
        # 当前位置
        self.AxisCurP = curP
        # 目标位置
        self.AxisAimP = aimP
        # 速度 单位 mm/s
        self.AxisVi = vi
        # 电机地址
        self.MotorAddr = addr
class PipetState:
    def __init__(self):
        self.curStep = " "
        self.tubeNum = 0
        self.bottleNum = 0
        self.gunheadNum = 0
        self.volunme = 0

class CPipLiquid:

    motor = MotorDriver.CDM57_StepMotor()
    state = PipetState()
    xAxisState = AxisState(0 , 0, 190 ,1)
    yAxisState = AxisState(0,0,190,2)
    zAxisState = AxisState(0,0,190,3)
    knobMoState = AxisState(0,0,190,4)
    pressMoState = AxisState(0,0,190,5)
    retractiMoState = AxisState(0,0,190,6)
    cfgDict = dict()
    bottlePos = list()
    tubePos = list()
    volumes = list()
    gunHeadPos =list()
    gunHeadHeight = 0
    liquidGunState = dict()
    WasteBoxPos = list()
    
    #TODO:UPDATE——调整量程时 当前的电机脉冲数
    motorCurPos = 0
    def __init__(self):
        #所有电机回零位，并进入初试位置
        print('init')
        time.sleep(1.5)
        self.Axiszeroing(ZAxisAddr)
        while self.motor.GetMotorPotionPulse(ZAxisAddr) != 0:
            time.sleep(0.3)
        time.sleep(0.3)
        self.Axiszeroing(XAxisAddr)
        time.sleep(0.2)
        self.Axiszeroing(YAxisAddr)
        time.sleep(0.2)
        self.Axiszeroing(PressMoAddr)
        time.sleep(0.2)
        self.Axiszeroing(ReactMoAddr)
        while self.motor.GetMotorPotionPulse(XAxisAddr) != 0 or \
                self.motor.GetMotorPotionPulse(YAxisAddr) != 0 or \
                self.motor.GetMotorPotionPulse(PressMoAddr) != 0 or \
                self.motor.GetMotorPotionPulse(ReactMoAddr) != 0:
            print('wait for zeroing')
            time.sleep(0.3)
        print(self.xAxisState.MotorAddr)
        print(self.yAxisState.MotorAddr)
        print(self.zAxisState.MotorAddr)

    def ReadCfg(self,):
        # 获取当前脚本所在文件夹路径
        curPath = os.path.dirname(os.path.realpath(__file__))
        # 获取yaml文件路径
        yamlPath = os.path.join(curPath, "config.yaml")
        with open(yamlPath, 'r', encoding='utf-8') as f:
            self.cfgDict = yaml.load(f.read(), Loader=yaml.FullLoader)

        # print(result['Coordinate']['PlatformCoodinate'])
        # print(result['Coordinate']['PlatformCoodinate']['Container_01'])
        print(self.cfgDict)
        # for co in self.cfgDict['Platform']:
        #     print(co,':',self.cfgDict['Platform'][co])
        print('ReadCfg')

    def TransScheme(self,bottlesSerialArry, tubesSerialArray , volumesArray):
        # 获取取液地址list bottlePos
        for bottle in bottlesSerialArry:
            bottleContainerPx = self.cfgDict['Platform']['Container_'+str(bottle[0]).rjust(2,'0')]['AxisX']  #101
            bottleContainerPy = self.cfgDict['Platform']['Container_'+str(bottle[0]).rjust(2,'0')]['AxisY']  #102
            bottleContainerType = self.cfgDict['Platform']['Container_'+str(bottle[0]).rjust(2,'0')]['BoxType']
            bottleContainerX1St = self.cfgDict['Holder'][bottleContainerType]['AxisX1st']
            bottleContainerY1St = self.cfgDict['Holder'][bottleContainerType]['AxisY1st']
            bottleContainerXDelta = self.cfgDict['Holder'][bottleContainerType]['AxisXDelta']
            bottleContainerYDelta = self.cfgDict['Holder'][bottleContainerType]['AxisYDelta']
            #TODO： DeltaX * 列数   DeltaY * 行数
            self.bottlePos.append( [ bottleContainerPx + bottleContainerX1St + bottleContainerXDelta * (bottle[1][1] - 1),\
                              bottleContainerPy + bottleContainerY1St + bottleContainerYDelta * (bottle[1][0] - 1) ] )
        print(self.bottlePos)
        # del self.bottlePos[0]

        # 获取试管地址list tubePos
        for tube in tubesSerialArray:
            tubeContainerPx = self.cfgDict['Platform']['Container_' + str(tube[0]).rjust(2, '0')]['AxisX']
            tubeContainerPy = self.cfgDict['Platform']['Container_' + str(tube[0]).rjust(2, '0')]['AxisY']
            tubeContainerType = self.cfgDict['Platform']['Container_' + str(tube[0]).rjust(2, '0')]['BoxType']
            tubeContainerX1St = self.cfgDict['Holder'][tubeContainerType]['AxisX1st']
            tubeContainerY1St = self.cfgDict['Holder'][tubeContainerType]['AxisY1st']
            tubeContainerXDelta = self.cfgDict['Holder'][tubeContainerType]['AxisXDelta']
            tubeContainerYDelta = self.cfgDict['Holder'][tubeContainerType]['AxisYDelta']
            self.tubePos.append(
                [tubeContainerPx + tubeContainerX1St + tubeContainerXDelta * (tube[1][1] - 1), \
                 tubeContainerPy + tubeContainerY1St + tubeContainerYDelta * (tube[1][0] - 1)])
            #print('tubeContainerPx')
        print(self.tubePos)

        self.volumes = volumesArray
        self.liquidGunState = self.cfgDict['PipGunCfg']
        print(self.liquidGunState)

        # 获取枪头位置，当前只支持一个枪头和
        # TODO：后期可以换枪时候，需要编写支持多种枪头的代码
        for container in self.cfgDict['Platform'] : #container是key
            print(container)
            if 'GunHeadHolder' in self.cfgDict['Platform'][container]['BoxType'] :
                gunheadContainerTyepe = self.cfgDict['Platform'][container]['BoxType']
                gunheadContainerPx = self.cfgDict['Platform'][container]['AxisX']
                gunheadContainerPy = self.cfgDict['Platform'][container]['AxisY']
                gunheadContainerX1st = self.cfgDict['Holder'][gunheadContainerTyepe]['AxisX1st']
                gunheadContainerY1st = self.cfgDict['Holder'][gunheadContainerTyepe]['AxisY1st']
                gunheadContainerXDelta = self.cfgDict['Holder'][gunheadContainerTyepe]['AxisXDelta']
                gunheadContainerYDelta = self.cfgDict['Holder'][gunheadContainerTyepe]['AxisYDelta']
                gunheadContainerRow = self.cfgDict['Holder'][gunheadContainerTyepe]['RowsNum']
                gunheadContainerColumn = self.cfgDict['Holder'][gunheadContainerTyepe]['ColumnsNum']
                self.gunHeadHeight = self.cfgDict['Holder'][gunheadContainerTyepe]['Height']
                # 把盒子里所有的枪头位置都算出来 ，用掉多少都可以
                for gunheadx in range( gunheadContainerRow +1 ):
                    for gunheady in range( gunheadContainerColumn +1 ):
                        self.gunHeadPos.append(\
                            [gunheadContainerPx + gunheadContainerX1st + gunheady*gunheadContainerYDelta,\
                             gunheadContainerPy + gunheadContainerY1st + gunheadx*gunheadContainerXDelta])
                print (self.gunHeadPos)
            if 'WasteBox' in self.cfgDict['Platform'][container]['BoxType']:
                WasteBox_Px = self.cfgDict['Platform'][container]['AxisX']
                WasteBox_Py = self.cfgDict['Platform'][container]['AxisY']
                self.WasteBoxPos.append([WasteBox_Px,WasteBox_Py])
                

    def ExcuteScheme(self):
        print('ExcuteScheme')
        tubeNum = len(self.tubePos)
        bottleNum = len(self.bottlePos)
        WasteBox_Px = self.WasteBoxPos[0][0]
        WasteBox_Py = self.WasteBoxPos[0][1]

        for bottleXY in self.bottlePos:
            # 1 安装枪头
                # (1)去第一个枪头位置
            self.GoToXY(self.gunHeadPos[0][0],self.gunHeadPos[0][1])
            self.gunHeadPos.pop(0)
                # (2)安装枪头,并且 z 轴回到高位
            self.InstallGunhead(self.gunHeadHeight)
            # 2 按试管顺序吸液 排液
            for tubeXY in self.tubePos:
                #TODO:volumes[0] ?? ——>self.volumes[self.bottlePos.index(bottleXY)][self.tubePos.index(tubeXY)]
                curTotleVolume = self.volumes[self.bottlePos.index(bottleXY)][self.tubePos.index(tubeXY)]
                # 优化出取液序列
                # TODO: 当前只做量程范围内的移液，超过量程的优化组合序列后期再写
                _liquidSerial = list()
                # _liquidSerial.append(curTotleVolume)
                self.GenLiquidSerial(curTotleVolume,_liquidSerial)
                print(_liquidSerial)
                for _curVolume in _liquidSerial :
                    print('第',self.bottlePos.index(bottleXY),'个试剂瓶，吸液',_curVolume,'ml')
                    # 1 去吸液位置
                    self.GoToXY(self.bottlePos[0][0],self.bottlePos[0][1])
                    # 2 吸取
                    #self.ChangeVolume(_curVolume)
                    self.DrawLiquid(100,_curVolume)

                    print('第',self.tubePos.index(tubeXY),'个试管，排液',_curVolume,"ml")
                    # 3 去排液位置
                    self.GoToXY(self.tubePos[0][0],self.tubePos[0][1])
                    # 4 排液
                    self.ExhaustLiguid(100)
            # 3 退枪头
            # （1）去废料盒位置
            self.GoToXY(WasteBox_Px,WasteBox_Py)
            # （2）退枪头
            self.UnistallGunhead()
        self.ChangePipetGun()
        print('Excute Complete')
            #4 结束本种试剂，进入下一种试剂或结束

    # 用于单次单个轴运动，包括 z轴 按压轴 旋转轴 退枪轴
    def SingleMove(self, axisState : AxisState):

        self.motor.MoveMotorPostion(axisState.MotorAddr , axisState.AxisAimP)
        self.motor.IsAxisStop(axisState.MotorAddr,axisState.AxisAimP)
        #time.sleep(abs(axisState.AxisAimP - axisState.AxisCurP)/axisState.AxisVi + 0.5)
        _reachFlag = self.WaitForReachTarget(axisState)
        if _reachFlag :
            return  True
        else:
            return False

     # 驱动 x y轴到目标 px py 位置，单位mm 同时运动
    def GoToXY(self, px, py):

        # 设置运动轴的状态，并驱动它
        self.xAxisState.AxisCurP = self.motor.GetMotorPotion(XAxisAddr)
        self.xAxisState.AxisAimP = px
        self.motor.MoveMotorPostion(XAxisAddr, px)

        self.yAxisState.yAxisCurP = self.motor.GetMotorPotion(YAxisAddr)
        self.yAxisState.AxisAimP = py
        self.motor.MoveMotorPostion(YAxisAddr, py)

        self.motor.IsAxisStop(XAxisAddr, px)
        self.motor.IsAxisStop(YAxisAddr, py)

        # # 等待时间根据速度计算 并增加余量
        #time.sleep(max(abs(px - self.xAxisState.AxisCurP)/self.xAxisState.AxisVi ,abs(py - self.yAxisState.AxisCurP)/self.yAxisState.AxisVi ) + 5 )
        # self.xAxisState.AxisCurP = self.motor.GetMotorPotion(XAxisAddr)
        # print('xAxisState.AxisCurP:', self.xAxisState.AxisCurP)
        # self.yAxisState.AxisCurP = self.motor.GetMotorPotion(YAxisAddr)
        # print('yAxisState.AxisCurP:', self.yAxisState.AxisCurP)
        # print('yAxisState.AxisAimP:', self.yAxisState.AxisAimP)

        # 等待时间，如果重启后，都不能到达，则报错
        _xReachFlag = self.WaitForReachTarget(self.xAxisState)
        _yReachFlag = self.WaitForReachTarget(self.yAxisState)
        if _xReachFlag and _yReachFlag:
            return  True
        else:
            return False
        
    # 装枪头
    def InstallGunhead(self, gunheadHeight):
        self.motor.MotorTempSpeedSetting(ZAxisAddr,51200)
        self.zAxisState.AxisAimP = gunheadHeight
        self.SingleMove(self.zAxisState)
        self.motor.MotorTempSpeedSetting(ZAxisAddr, 102400)
        #time.sleep(0.5)
        #上台z轴至安全高度
        self.zAxisState.AxisAimP = 10
        self.SingleMove(self.zAxisState)
        #time.sleep(0.5)
        print('InstallGunhead')

    # 退枪头
    def UnistallGunhead(self):
        print('UnistallGunhead')
        self.zAxisState.AxisAimP = 100
        self.SingleMove(self.zAxisState)

        self.retractiMoState.AxisAimP = 500
        self.SingleMove(self.retractiMoState)

        self.retractiMoState.AxisAimP = 10
        self.SingleMove(self.retractiMoState)

        self.zAxisState.AxisAimP = 10
        self.SingleMove(self.zAxisState)
        print('UnistallGunhead completed')

    # 吸取液体
    # TODO：根据当前取液量程 确定吸取液体后按压电机回到的位置
    def DrawLiquid(self,bottleHeight,aimVolume):
        print('Draw Liquid')
        #0. 读取上次取液后的移液枪属性
        # curVolume = self.liquidGunState["RangeCurValue"]
        _gundelta = self.liquidGunState["RangeDelta"]
        _gunlower = self.liquidGunState["RangeLowerLimit"]
        _gunupper = self.liquidGunState["RangeUpperLimit"]
        #1. 调整取液量程 调整量程后 按压电机已经下压
        self.ChangeVolume(_gundelta, aimVolume)
        #2. Z轴下降，降到取液高度
        self.zAxisState.AxisAimP = bottleHeight
        self.SingleMove(self.zAxisState)
        #3. 按压轴上抬，取液
        #TODO：假设RangeUpperLimit对应0mm RangeLowerLimit对应50mm
        self.pressMoState.AxisAimP = 50 - ((aimVolume - _gunlower) / (_gunupper - _gunlower)) * 50
        self.SingleMove(self.pressMoState)
        #4. Z轴上抬到安全高度
        self.zAxisState.AxisAimP = 10
        self.SingleMove(self.zAxisState)
        #time.sleep(0.5)
        print('Draw Liquid Completed')

    # 排除液体
    # TODO：根据当前取液量程 确定排出液体后按压电机回到的位置
    def ExhaustLiguid(self,tubeHeight):
        print('Exhaust Liquid')
        curVolume = self.liquidGunState["RangeCurValue"]
        _gunlower = self.liquidGunState["RangeLowerLimit"]
        _gunupper = self.liquidGunState["RangeUpperLimit"]
        #1. Z轴下降到试管排液高度
        self.zAxisState.AxisAimP = tubeHeight
        self.SingleMove(self.zAxisState)
        #2、按压轴下压 排出液体
        self.pressMoState.AxisAimP = 300
        self.SingleMove(self.pressMoState)
        #3、按压轴上抬，排液完成
        self.pressMoState.AxisAimP = 50 - ((curVolume - _gunlower) / (_gunupper - _gunlower)) * 50
        self.SingleMove(self.pressMoState)
        #4、Z轴上抬到安全高度
        self.zAxisState.AxisAimP = 10
        self.SingleMove(self.zAxisState)
        print('Exhaust Liquid Completed')

    # 调整量程
    # TODO：调整量程结束后，按压轴电机不上抬
    def ChangeVolume(self,deltaVolume, aimVolume):
        print('ChangeVolume')
        #电机256细分 512000脉冲转一圈 一圈对应10格
        #1、 计算旋转的步数
        maxVolume = self.liquidGunState["RangeUpperLimit"]
        Pulse_ = 5120 * int((maxVolume-aimVolume) / deltaVolume)
        pos_ = Pulse_ / 51200 * 72
        print(pos_)
        # 1、下压按压电机，准备调整量程
        self.pressMoState.AxisAimP = 200
        self.SingleMove(self.pressMoState)

        #2.1 不需要调整量程
        if pos_ == 0:
            return
        #2.2 需要调整量程
        else:
            #3. 调整量程
            self.motor.MoveMotorPostion(self.knobMoState.MotorAddr,pos_)
            self.motor.IsAxisStop(self.knobMoState.MotorAddr,pos_)
            #4、更新数据
            self.motorCurPos = pos_
            self.liquidGunState["RangeCurValue"] = aimVolume
            return
    
    def ChangePipetGun(self):
        """
        移出XY轴 方便实验人员换不同量程的移液枪
        """
        self.GoToXY(280,300)
        self.zAxisState.AxisAimP = 10
        self.SingleMove(self.zAxisState)



    def WaitForReachTarget(self, axisState : AxisState):
        _reachFlag = True        # 如果到达预订位置，正常返回 并置当前位置
        print('axis:', axisState.MotorAddr\
              ,'curP:' , self.motor.GetMotorPotionPulse(axisState.MotorAddr)
              ,'aimP:',int(axisState.AxisAimP/72*51200) )
        if self.motor.GetMotorPotionPulse(axisState.MotorAddr) == int(axisState.AxisAimP/72*51200):
            axisState.AxisCurP = axisState.AxisAimP

        # 如果没有到达预订位置 则重新使能电机驱动
        else:
            self.motor.ResetMotor(axisState.MotorAddr)
            time.sleep(0.3)
            self.Axiszeroing(axisState.MotorAddr)
            while self.motor.GetMotorPotionPulse(axisState.MotorAddr) != 0:
                time.sleep(0.3)
            self.motor.MoveMotorPostion(axisState.MotorAddr, axisState.AxisAimP)
            time.sleep(axisState.AxisAimP / axisState.AxisVi + 0.5)
            # 如果重新使能后到达预订位置，正常返回 并置当前位置
            if self.motor.GetMotorPotion(axisState.MotorAddr) == axisState.AxisAimP:
                axisState.xAxisCurP = axisState.AxisAimP
            # 如果重新使能后依然无法到达预定位置，则报错
            else:
                _reachFlag = False
        return _reachFlag

    # 对指定轴 归零
    def Axiszeroing(self, slaveAddr):
        self.motor.MotorZeroing(slaveAddr)
        print('Zero axis : ', slaveAddr)

    # 生成取液序列，取液量优化
    def GenLiquidSerial(self, totleVolume: int, liquidSerial: list):
        _gunlower = self.liquidGunState['RangeLowerLimit']
        _gunupper = self.liquidGunState['RangeUpperLimit']
        _gunDelta = self.liquidGunState['RangeDelta']
        while totleVolume > int(_gunupper * 1.3):
            totleVolume = totleVolume - _gunupper
            liquidSerial.append(_gunupper)
        if totleVolume > _gunupper:
            if totleVolume / _gunDelta % 2 == 0:  # 取液量是增量的偶数倍
                liquidSerial.append(int(totleVolume / 2))
                liquidSerial.append(int(totleVolume / 2))
            else:  # 取液量是增量的奇数倍
                liquidSerial.append(int((totleVolume + _gunDelta) / 2))
                liquidSerial.append(int((totleVolume - _gunDelta) / 2))
        else:
            liquidSerial.append(totleVolume)
        print(sum(liquidSerial), liquidSerial)