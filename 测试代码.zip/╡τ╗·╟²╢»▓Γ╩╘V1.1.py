import json
import time
import zmq
import serial
import binascii
import crcmod.predefined

def modbus(ip, func_code, addr, data, res_num):
    # ip: 从机IP, func_code: 功能码(3查询 6修改) addr: 地址(查询/修改地址) data: 数据(查询位数/修改数据)
    # res_num:寄存器数量，byte_num:字节数量
    if res_num == 1:
        addr = hex(addr)[2:]  # 10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4, '0') + data.rjust(4, '0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        # print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3
    elif res_num == 2:
        addr = hex(addr)[2:]  # 10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        byte_num = res_num * 2
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4,
                                                                   '0') + "%04d" % res_num + "%02d" % byte_num + data.rjust(
            8, '0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        # print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3


def SendData(ip, func_code, addr, data, res_num):  # 修改
    _str = modbus(ip, func_code, addr, data, res_num)
    send_data = _str
    send_data = binascii.unhexlify(send_data)
    # send_data = send_data.decode('hex')    # 发送数据转换为b'\xff\x01\x00U\x00\x00V'
    ser.write(send_data)  # 发送命令
    time.sleep(0.1)


def QueryData(ip, func_code, addr, data, res_num):  # 查询
    SendData(ip, func_code, addr, data, res_num)
    len_return_data = None  # 获取缓冲数据（接收数据）长度
    while len_return_data is None:
        len_return_data = ser.inWaiting()
        return_data = ser.read(len_return_data)  # 读取缓冲数据
        str_return_data = binascii.hexlify(return_data)
        print(str_return_data)
    return str_return_data


def Motor_Init(ip):
    # 设定最大找零步数
    QueryData(ip, 16, 3010, 1000000, 2)
    # 设定开关脱落步数
    QueryData(ip, 16, 3014, 3000, 2)


def Motor_Reset(ip):
    QueryData(ip, 6, 2000, 0, 1)


def Motor_Status(ip):
    try:
        rets = QueryData(ip, 3, 1004, 1, 1)[8:10]
    except TypeError:
        time.sleep(10)
        rets = b'00'
    return rets


def Cur_Pos(ip):
    pos = QueryData(ip, 3, 1000, 2, 1)[6:14]
    return pos


def Motor_Locate(ip, position):
    QueryData(ip, 16, 2202, position, 2)

def Motor_Forward(ip, position):
    QueryData(ip, 16, 2004, position, 2)


def Motor_Back(ip, position):
    QueryData(ip, 16, 2006, position, 2)


def Motor_stopcheck(ip):
    while True:
        status = Motor_Status(ip)
        time.sleep(1)
        if (status == b'00'):
            break


if __name__ == "__main__":
    ser = serial.Serial('com20', 9600) # 选择串口，并设置波特率
    if ser.is_open:
        print("port open success")
        # while True:
        #     for ip in range(1,9):
        #         Cur_Pos(ip)
        #         time.sleep(0.5)

        while True:
            for ip in range(1,9):
                if ip == 6:
                    continue
                else:
                    Motor_Forward(ip, 10000)
                    Motor_stopcheck(ip)
                    Motor_Back(ip, 10000)
                    Motor_stopcheck(ip)

