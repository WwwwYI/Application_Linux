# -*- coding:utf-8 -*-
# Author: WwwwYI
# Ubuntu16.04&Python3

import serial
import time
import os
import binascii
import crcmod.predefined

def modbus(ip, func_code, addr, data, res_num):
    # ip: 从机IP, func_code: 功能码(3查询 6修改) addr: 地址(查询/修改地址) data: 数据(查询位数/修改数据)
    # res_num:寄存器数量，byte_num:字节数量
    if res_num==1:
        addr = hex(addr)[2:] #10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4,'0') + data.rjust(4,'0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        #print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3
    elif res_num == 2:
        addr = hex(addr)[2:]  # 10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        byte_num = res_num * 2
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4,'0') + "%04d" %res_num +"%02d" % byte_num + data.rjust(8,'0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        # print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3


def SendData(ip, func_code, addr, data,res_num):   #修改
    _str = modbus(ip, func_code, addr, data, res_num)
    send_data = _str
    send_data = binascii.unhexlify(send_data)
    #send_data = send_data.decode('hex')    # 发送数据转换为b'\xff\x01\x00U\x00\x00V'
    ser.write(send_data)   # 发送命令
    time.sleep(0.1)

def QueryData(ip, func_code, addr, data,res_num):  #查询
    SendData(ip, func_code, addr, data,res_num)
    len_return_data = ser.inWaiting()  # 获取缓冲数据（接收数据）长度
    if len_return_data:
        return_data = ser.read(len_return_data)  # 读取缓冲数据
        str_return_data = binascii.hexlify(return_data)
        print(str_return_data)
        return str_return_data
def Motor_Init(ip):
    #设定最大找零步数
    QueryData(ip, 16, 3010, 1000000, 2)
    #设定开关脱落步数
    QueryData(ip, 16, 3014, 3000, 2)


def Motor_Reset(ip):
    QueryData(ip,6,2000,0,1)

def Motor_Status(ip):
    ret = QueryData(ip, 3, 1004, 1, 1)[8:10]
    return ret

def Cur_Pos(ip):
    pos = QueryData(ip, 3, 1000, 2, 1)[6:14]
    return pos

def Motor_Locate(ip,position):
    QueryData(ip, 16, 2202, position, 2)

def Motor_Forward(ip,position):
    QueryData(ip, 16, 2004, position, 2)

def Motor_Back(ip,position):
    QueryData(ip, 16, 2006, position, 2)

def Motor_stopcheck(ip):
    while True:
        status = Motor_Status(ip)
        time.sleep(0.5)
        if(status == b'00' ):
            break

#五个电机的初始化：
def yaxis_init(ip=1):
    # 初始化y轴 ip；1
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Y_axis reset begin")
    #暂定y轴z轴同时初始化
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('y-axis init done')


def zaxis_init(ip=2):
    # 初始化z轴 ip；2
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Z_axis reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('z-axis init done')

def xaxis_init(ip=3):
    # 初始化x轴 ip；3
    Motor_Init(ip)
    Motor_Reset(ip)
    print("X_axis reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('x-axis init done')

def pressmotor_init(ip = 4):
    # 初始化取液高度电机 ip；4
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Height_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('height-motor init done')

def rotatemotor_init(ip=5):
    # 初始化旋转电机 ip；5
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Rotate_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('rotate-motor init done')

def suckmotor_init(ip=6):
    # 初始化吸盘电机 ip；6
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Suck_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('suck-motor init done')


def needlemotor_init(ip=7):
    # 初始化针管电机 ip；7
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Needle_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('needle-motor init done')


def pressneedle_init(ip=8):
    # 初始化针管下压电机 ip；8
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Pressneedle_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('press-needle init done')

def back_tips():
    #y轴伸出同时x轴移动
    Motor_Locate(1,29000)
    Motor_Locate(3, 58000)
    #等x轴停下后再移动z轴，下降至退枪头的高度
    Motor_stopcheck(3)
    Motor_Locate(2, 120000)
    #等待z轴完全停下后再调整x轴位置，移液枪进入退枪头区域
    Motor_stopcheck(2)
    #x轴移动，移液枪进入金属块下方
    Motor_Locate(3, 60700)
    Motor_stopcheck(3)
    #退枪头操作
    Motor_Locate(2, 110000)
    Motor_stopcheck(2)
    #z轴下降至安全高度
    Motor_Locate(2, 125000)
    Motor_stopcheck(2)
    #x轴移出退枪头区域
    Motor_Locate(3, 56000)
    Motor_stopcheck(3)
    #z轴上升至安全高度
    Motor_Locate(2, 50000)
    Motor_stopcheck(2)

def change_tips(num):
    """

    :param num: 从第几号枪头开始换起 默认第一个的标号0
    :return: num+1 下一次更换枪头的标号
    """
    tips0_pos = {'tips0_x': 40100, 'tips0_y': 28000}
    row = int(num / 6)
    colume = num % 6
    tip_des_x = tips0_pos['tips0_x'] + colume * 1400
    tip_des_y = tips0_pos['tips0_y'] + row * 1373
    Motor_Locate(1, tip_des_y)
    Motor_Locate(3, tip_des_x)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    #Z轴套枪头
    Motor_Locate(2, 121500)
    Motor_stopcheck(2)
    #Z轴抬起到安全高度
    Motor_Locate(2, 50000)
    Motor_stopcheck(2)
    # Motor_Locate(1,0)
    # Motor_Locate(3,0)
    # Motor_stopcheck(3)
    # Motor_stopcheck(3)
    return num + 1


def Fetch_liquid(pre_volume,x_scr_pos,y_scr_pos,x_des_pos,y_des_pos):
    """
    单次取液体 量程从200ul开始
    """
    #Motor_Locate(2,0) #z轴归零
    #Motor_stopcheck(2)
    #定位到原料瓶位置
    Motor_Locate(1,y_scr_pos)
    Motor_Locate(3,x_scr_pos)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    # 取液 z轴下降，按压轴按下排出空气
    # #按压轴有两个键程，取液时按到第一个键程
    Motor_Locate(4,30000)
    #TODO: 没有试剂瓶，z轴位置要重新确定
    Motor_Locate(2,115000)
    Motor_stopcheck(4) #等待z轴和按压轴运动停止
    Motor_stopcheck(2)

    #按压轴上抬 吸取液体
    Motor_Locate(4, 320*(200-pre_volume))
    Motor_stopcheck(4)
    # TODO: 没有试剂瓶，z轴位置要重新确定
    Motor_Locate(2, 50000)
    Motor_stopcheck(2)
    #定位到反应试管的位置
    Motor_Locate(1,y_des_pos)
    Motor_Locate(3,x_des_pos)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    #注射液体
    Motor_Locate(2,80000)
    Motor_stopcheck(2)
    #排出（注射）液体时按到第二个键程
    #TODO：改了一下，减少一点量程
    Motor_Locate(4,37500)
    Motor_stopcheck(4)
    #两轴退回
    Motor_Locate(4, (200-pre_volume)*320)
    Motor_stopcheck(4)
    # TODO: 没有试剂瓶，z轴位置要重新确定
    Motor_Locate(2, 50000)
    Motor_stopcheck(2)

def change_volume(thistime_volume,lasttime_volume = 200):
    """
    :param thistime_volume: 本次取液的体积
    :param lasttime_volume: 取液前移液枪的量程数字，默认200μL
    :return: thistime_volum 这一次取液的体积
    """
    step = 640 * int((abs(lasttime_volume-thistime_volume)))
    if step == 0:
        return thistime_volume
    # 按压轴下降10000步 套住旋钮
    else:
        Motor_Locate(4, 28000)
        Motor_stopcheck(4)
        if thistime_volume > lasttime_volume:
            Motor_Forward(5,step)
            Motor_stopcheck(5)
        else:
            Motor_Back(5,step)
            Motor_stopcheck(5)
        Motor_Locate(4,300*(200-thistime_volume))
        Motor_stopcheck(4)
        return thistime_volume

def tramform_liquid(volume,init_vol,x_scr_pos,y_scr_pos,x_des_pos,y_des_pos):
    """
    :param volume: 需要取液的总体积
    :param init_vol: 初次移液枪的取液量程，初始量程200μL
    :param source_id: 反应原液的目标位置（以id的形式给出）
    :param dest_id: 待加入试剂试管的的目标位置（以id的形式给出）
    :return:thistime_volume 最后一次取液体积
    """
    last_volume = volume
    if volume >= 200:
        if init_vol != 200:
            change_volume(200, init_vol)
            init_vol = 200
        times = int(volume / init_vol)
        last_volume  = volume % init_vol
        # if last_volume == 0:
        #     last_volume = 200
        i = 0
        while i < times:
            Fetch_liquid(init_vol,x_scr_pos,y_scr_pos,x_des_pos,y_des_pos)
            i += 1
        if last_volume != 0:
            change_volume(last_volume,init_vol)
            Fetch_liquid(last_volume,x_scr_pos, y_scr_pos, x_des_pos, y_des_pos)
        if last_volume == 0:
            last_volume = 200
    else:
        last_volume = change_volume(last_volume, init_vol)
        Fetch_liquid(last_volume,x_scr_pos, y_scr_pos, x_des_pos, y_des_pos)

    return last_volume

if __name__ == "__main__":

    ser = serial.Serial('com16', 9600) # 选择串口，并设置波特率
    if ser.is_open:
        print("port open success")
    else:
        print("port open failed")

    zaxis_init()
    needlemotor_init()
    yaxis_init()
    xaxis_init()
    pressmotor_init()

    tip_num = 0
    volume_all = [[200 ,175],[390,380]]
    scr_pos = [[2,0],[2,1]]
    dst_pos = [[5,0],[5,1]]
    # id标号为1的区域第一个原料瓶(标号0)的坐标
    id1_pos = {'scr_x': 42700, 'scr_y': 19700}
    # id标号为2的区域第一个原料瓶(标号0)的坐标
    id2_pos = {'scr_x': 42700, 'scr_y': 6300}
    # id标号为5的区域第一个试管（标号0）的坐标
    id5_pos = {'dst_x': 21150, 'dst_y': 2850}

    ret = 200
    for i in range(len(volume_all)):
         scr_row = int(scr_pos[i][1]/2)
         scr_column = scr_pos[i][1]%2
         if scr_pos[i][0] == 2:
             scr_axis_x = id2_pos['scr_x'] + scr_column * 7000
             scr_axis_y = id2_pos['scr_y'] + scr_row * 2000
         elif scr_pos[i][0] == 1:
            scr_axis_x = id1_pos['scr_x'] + scr_column * 7000
            scr_axis_y = id1_pos['scr_y'] + scr_row * 2000
         for j in range(len(volume_all[i])):
             dst_row = int(dst_pos[j][1]/4)
             dst_column = dst_pos[j][1]%4
             dst_axis_x = id5_pos['dst_x'] + dst_column * 4500
             dst_axis_y = id5_pos['dst_y'] + dst_row * 3660
             ret = tramform_liquid(volume_all[i][j], ret, scr_axis_x, scr_axis_y,dst_axis_x,dst_axis_y)

         back_tips()
         xaxis_init()
         tip_num = change_tips(tip_num)

if ret != 200:
    change_volume(200,ret)

Motor_Locate(2,0)

Motor_Locate(1,37000)
Motor_stopcheck(1)



