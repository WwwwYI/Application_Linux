# -*- coding:utf-8 -*-
# Author: WwwwYI
# Ubuntu16.04&Python3

import serial
import time
import os
import binascii
import crcmod.predefined


def modbus(ip, func_code, addr, data, res_num):
    # ip: 从机IP, func_code: 功能码(3查询 6修改) addr: 地址(查询/修改地址) data: 数据(查询位数/修改数据)
    # res_num:寄存器数量，byte_num:字节数量
    if res_num == 1:
        addr = hex(addr)[2:]  # 10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4, '0') + data.rjust(4, '0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        # print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3
    elif res_num == 2:
        addr = hex(addr)[2:]  # 10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        byte_num = res_num * 2
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4,
                                                                   '0') + "%04d" % res_num + "%02d" % byte_num + data.rjust(
            8, '0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        # print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3


def SendData(ip, func_code, addr, data, res_num):  # 修改
    _str = modbus(ip, func_code, addr, data, res_num)
    send_data = _str
    send_data = binascii.unhexlify(send_data)
    # send_data = send_data.decode('hex')    # 发送数据转换为b'\xff\x01\x00U\x00\x00V'
    ser.write(send_data)  # 发送命令
    time.sleep(0.1)


def QueryData(ip, func_code, addr, data, res_num):  # 查询
    SendData(ip, func_code, addr, data, res_num)
    len_return_data = ser.inWaiting()  # 获取缓冲数据（接收数据）长度
    if len_return_data:
        return_data = ser.read(len_return_data)  # 读取缓冲数据
        str_return_data = binascii.hexlify(return_data)
        print(str_return_data)
        return str_return_data


def Motor_Init(ip):
    # 设定最大找零步数
    QueryData(ip, 16, 3010, 1000000, 2)
    # 设定开关脱落步数
    QueryData(ip, 16, 3014, 3000, 2)


def Motor_Reset(ip):
    QueryData(ip, 6, 2000, 0, 1)


def Motor_Status(ip):
    ret = QueryData(ip, 3, 1004, 1, 1)[8:10]
    return ret


def Cur_Pos(ip):
    pos = QueryData(ip, 3, 1000, 2, 1)[6:14]
    return pos


def Motor_Locate(ip, position):
    QueryData(ip, 16, 2202, position, 2)


def Motor_Forward(ip, position):
    QueryData(ip, 16, 2004, position, 2)


def Motor_Back(ip, position):
    QueryData(ip, 16, 2006, position, 2)


def Motor_stopcheck(ip):
    while True:
        status = Motor_Status(ip)
        time.sleep(0.5)
        if (status == b'00'):
            break


# ⑧个电机的初始化：
def yaxis_init(ip=1):
    # 初始化y轴 ip；1
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Y_axis reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('y-axis init done')


def zaxis_init(ip=2):
    # 初始化z轴 ip；2
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Z_axis reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('z-axis init done')


def xaxis_init(ip=3):
    # 初始化x轴 ip；3
    Motor_Init(ip)
    Motor_Reset(ip)
    print("X_axis reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('x-axis init done')


def pressmotor_init(ip=4):
    # 初始化取液高度电机 ip；4
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Height_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('height-motor init done')


def rotatemotor_init(ip=5):
    # 初始化旋转电机 ip；5
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Rotate_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('rotate-motor init done')


def suckmotor_init(ip=6):
    # 初始化吸盘电机 ip；6
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Suck_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('suck-motor init done')


def needlemotor_init(ip=7):
    # 初始化针管电机 ip；7
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Needle_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('needle-motor init done')


def pressneedle_init(ip=8):
    # 初始化针管下压电机 ip；8
    Motor_Init(ip)
    Motor_Reset(ip)
    print("Pressneedle_motor reset begin")
    Motor_stopcheck(ip)
    pos = int(Cur_Pos(ip), 16)
    if pos == 0:
        print('press-needle init done')


def needle_fetch(x_scr_pos, y_scr_pos, x_des_pos, y_des_pos, id):
    # id = 1,吸取反应产物
    # id = 2，吸取稀释液
    # 定位到反应完的试管位置或稀释液
    Motor_Locate(1, y_scr_pos)
    Motor_Locate(3, x_scr_pos)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    # 针管轴下降，针管按压轴按下排出空气
    Motor_Locate(8, 96000)
    if id == 1:
        Motor_stopcheck(8)
        Motor_Locate(7, 295000)
        Motor_stopcheck(7)
    elif id == 2:
        Motor_stopcheck(8)
        Motor_Locate(7, 275000)
        Motor_stopcheck(7)
    # 等待z3轴和按压轴运动停止
    # 按压轴上抬 吸取反应产物(0.1-0.2ml)
    if id == 1:
        Motor_Locate(8, 85000)
        Motor_stopcheck(8)
    # 按压轴上抬 吸取稀释液(0.8ml左右）
    elif id == 2:
        Motor_Locate(8, 5000)
        Motor_stopcheck(8)

    Motor_Locate(7, 90000)
    Motor_stopcheck(7)
    # 定位到进样瓶的位置
    Motor_Locate(1, y_des_pos)
    Motor_Locate(3, x_des_pos)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    # 注射液体
    Motor_Locate(7, 275000)
    Motor_stopcheck(7)
    Motor_Locate(8, 96000)
    Motor_stopcheck(8)
    # 若是吸取稀释液，则要混合均匀 在进样瓶中混合
    if id == 2:
        # Motor_Locate(7, 275000)
        # Motor_stopcheck(7)
        # 针管按压轴上下混合液体两次
        for i in range(2):
            Motor_Locate(8, 0)
            Motor_stopcheck(8)
            Motor_Locate(8, 96000)
            Motor_stopcheck(8)
        # 吸取少许反应产物
        Motor_Locate(8, 10000)
        Motor_stopcheck(8)
    # 两轴退回
    Motor_Locate(7, 90000)
    Motor_stopcheck(7)
    # Motor_Locate(8, 0)
    # Motor_stopcheck(8)


def clean_needle():
    for i in range(2):
        # 定位到反应完的试管位置
        Motor_Locate(1, 34000)
        Motor_Locate(3, 48300)
        Motor_stopcheck(1)
        Motor_stopcheck(3)
        # 将针管中空气排尽
        # Motor_Locate(8, 96000)
        # Motor_stopcheck(8)
        Motor_Locate(7, 280000)
        Motor_stopcheck(7)
        Motor_Locate(8, 0)
        Motor_stopcheck(8)
        Motor_Locate(7, 50000)
        Motor_stopcheck(7)
        # 移入废液区域
        Motor_Locate(3, 6500)
        Motor_Locate(1, 33000)
        Motor_stopcheck(3)
        Motor_stopcheck(1)
        # 针管轴下降 按压轴排出液体
        #TODO:改了数值
        Motor_Locate(7, 250000)
        Motor_stopcheck(7)
        Motor_Locate(8, 96000)
        Motor_stopcheck(8)
        # 两电机上抬
        #清洗完成后就是换针头 不需要上抬
        # Motor_Locate(7, 80000)
        # Motor_stopcheck(7)
        # Motor_Locate(8, 0)
        # Motor_stopcheck(8)


def back():
    """
    实现退针头和枪头的功能
    """
    # y轴x轴移动到废料区域
    Motor_Locate(1, 31000)
    Motor_Locate(3, 5000)
    # 等y轴x轴停下后再移动z3轴，下降至退针头的高度
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    Motor_Locate(7, 81500)
    # 等待z3轴完全停下后再调整x轴位置，移液枪进入退枪头区域
    Motor_stopcheck(7)
    # x轴移动，针头进入金属块下方
    Motor_Locate(3, 800)
    Motor_stopcheck(3)
    # 退针头操作
    #TODO:改了数值
    Motor_Locate(7, 70000)
    Motor_stopcheck(7)
    # x轴至安全距离
    Motor_Locate(3, 5000)
    Motor_stopcheck(3)
    # z3轴上升至安全高度
    Motor_Locate(7, 5000)
    Motor_stopcheck(7)


def change_needles(needle_num):
    """
    :param needle_num: 从第几号针头开始换起 默认第一个的标号0
    :return: needle_num+1 下一次更换针头的标号
    """
    needle0_pos = {'needle0_x': 18900, 'needle0_y': 30200}
    row = int(needle_num / 6)  # (一排多少个针头个数未定)
    colume = needle_num % 6
    tip_des_x = needle0_pos['needle0_x'] + colume * 1320
    tip_des_y = needle0_pos['needle0_y'] + row * 1320
    Motor_Locate(1, tip_des_y)
    Motor_Locate(3, tip_des_x)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    # Z3轴套针头
    Motor_Locate(7, 315000)
    Motor_stopcheck(7)
    # Z3轴抬起到安全高度
    Motor_Locate(7, 90000)
    Motor_stopcheck(7)
    # Motor_Locate(1,0)
    # Motor_Locate(3,0)
    # Motor_stopcheck(3)
    # Motor_stopcheck(3)
    return needle_num + 1


def change_filters(filter_num):
    """
    :param filter_num: 从第几号过滤嘴开始换起 默认第一个的标号0
    :return:filter_num + 1 下一次更换过滤嘴的标号
    """
    filter0_pos = {'filter0_x': 18600, 'filter0_y': 16650}
    row = int(filter_num / 6)  # (一排多少个过滤嘴个数未定)
    colume = filter_num % 6
    filter_des_x = filter0_pos['filter0_x'] + colume * 2800
    filter0_des_y = filter0_pos['filter0_y'] + row * 2850
    Motor_Locate(1, filter0_des_y)
    Motor_Locate(3, filter_des_x)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    # Z3轴套过滤头
    Motor_Locate(7, 312000)
    Motor_stopcheck(7)
    # Z轴抬起到安全高度
    Motor_Locate(7, 90000)
    Motor_stopcheck(7)
    # Motor_Locate(1, 0)
    # Motor_Locate(3, 0)
    # Motor_stopcheck(1)
    # Motor_stopcheck(3)
    return filter_num + 1


def filter_fetch(x_dst_pos, y_dst_pos):
    Motor_Locate(1, y_dst_pos)
    Motor_Locate(3, x_dst_pos)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    # z3轴下降 到达进样瓶上方 下压针管
    Motor_Locate(7, 315000)
    Motor_stopcheck(7)
    Motor_Locate(8, 96000)
    Motor_stopcheck(8)
    # 两轴退回
    Motor_Locate(7, 90000)
    Motor_stopcheck(7)
    # Motor_Locate(8, 0)
    # Motor_stopcheck(8)


# 485继电器控制
# 485设备地址 09
# modbus报文
# 开关1 打开 09 05 00 00 FF 00 8D 72
# 开关1 关闭 09 05 00 00 00 00 CC 82

def modbu_relay(ip, func_code, addr, data, res_num):
    # ip: 从机IP, func_code: 功能码(3查询 6修改) addr: 地址(查询/修改地址) data: 数据(查询位数/修改数据)
    # res_num:寄存器数量，byte_num:字节数量
    if res_num==1:
        addr = hex(addr)[2:] #10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4,'0') + data.ljust(4,'0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        #print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3
    elif res_num==2:
        addr = hex(addr)[2:]  # 10转16进制
        data = hex(data)[2:]
        func_code = int(hex(func_code)[2:])
        byte_num = res_num * 2
        modbus_str = "%02d" % ip + "%02d" % func_code + addr.rjust(4,'0') + "%04d" %res_num +"%02d" % byte_num + data.rjust(8,'0')
        crc16 = crcmod.predefined.Crc('modbus')
        hexData = modbus_str
        hexData = binascii.unhexlify(hexData)
        crc16.update(hexData)
        result = hex(crc16.crcValue)
        # print(result)
        result1 = result[-2:]
        if len(result) > 5:
            result2 = result[-4:-2]
        else:
            result2 = '0' + result[-3:-2]
        result3 = modbus_str + result1 + result2
        print(result3)
        return result3


def SendData_relay(ip, func_code, addr, data,res_num):   #修改
    _str = modbus(ip, func_code, addr, data, res_num)
    send_data = _str
    send_data = binascii.unhexlify(send_data)
    #send_data = send_data.decode('hex')    # 发送数据转换为b'\xff\x01\x00U\x00\x00V'
    ser.write(send_data)   # 发送命令
    time.sleep(0.1)

def QueryData_relay(ip, func_code, addr, data,res_num):  #查询
    SendData(ip, func_code, addr, data,res_num)
    len_return_data = ser.inWaiting()  # 获取缓冲数据（接收数据）长度
    if len_return_data:
        return_data = ser.read(len_return_data)  # 读取缓冲数据
        str_return_data = binascii.hexlify(return_data)
        print(str_return_data)
        return str_return_data

def relay_open():
    QueryData_relay(9,5,00,65280,1)

def relay_close():
    QueryData_relay(9, 5, 00, 00, 1)


def relay_sip(num, clean_demo_x, clean_demo_y):
    sip_pos = {'sip0_x': 29700, 'sip0_y': 14500}
    row = int(num / 6)
    colume = num % 6
    sip_des_x = sip_pos['sip0_x'] + colume * 2850
    sip_des_y = sip_pos['sip0_y'] + row * 2872
    Motor_Locate(1, sip_des_y)
    Motor_Locate(3, sip_des_x)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    Motor_Locate(6, 320000)
    Motor_stopcheck(6)
    relay_open()
    time.sleep(0.5)
    Motor_Locate(6, 50000)
    Motor_stopcheck(6)
    Motor_Locate(1, clean_demo_y)
    Motor_Locate(3, clean_demo_x)
    Motor_stopcheck(1)
    Motor_stopcheck(3)
    Motor_Locate(6, 297000)
    Motor_stopcheck(6)
    relay_close()
    time.sleep(0.5)
    Motor_Locate(6, 50000)
    Motor_stopcheck(6)
    return num + 1


if __name__ == "__main__":

    ser = serial.Serial('com16', 9600)  # 选择串口，并设置波特率
    if ser.is_open:
        print("port open success")
    else:
        print("port open failed")

    needle_num = 0
    filter_num = 0
    sip_num = 0

    zaxis_init()
    suckmotor_init()
    needlemotor_init()
    pressneedle_init()
    xaxis_init()
    yaxis_init()

    # 目标试管的id
    tube_pos = [[5, 0], [5, 1]]
    # 混合进样瓶的id
    demo_pos = [[10, 0], [10, 1]]
    # 干净进样瓶id
    clean_demo_pos = [[11, 0], [11, 1]]

    # id标号为5的区域第一个试管(标号0)的坐标
    id5_pos_needle = {'tube_x': 38000, 'tube_y': 4100}
    # id标号为10的区域第一个进样瓶（混合）（标号0）的坐标
    id10_pos = {'demo_x': 9550, 'demo_y': 16800}
    # 稀释液的位置（标号0）坐标
    id3_dilute_pos = {'dilute_x': 41500, 'dilute_y': 34000}
    # 针管操作进样瓶（进样）的位置（标号0）坐标
    id11_pos_needle = {'clean_demo_x': 9300, 'clean_demo_y': 3800}
    # 继电器操作进样瓶（进样）的位置（标号0）坐标
    id11_pos_sip = {'clean_demo_x': 1700, 'clean_demo_y': 1550}

    for i in range(len(tube_pos)):
        # 计算针管取反应产物的坐标
        tube_row = int(tube_pos[i][1] / 4)
        tube_column = tube_pos[i][1] % 4
        tube_axis_x = id5_pos_needle['tube_x'] + tube_column * 4450
        tube_axis_y = id5_pos_needle['tube_y'] + tube_row * 3660
        # 计算针管采样混合的进样瓶坐标
        demo_row = int(demo_pos[i][1] / 3)
        demo_column = demo_pos[i][1] % 3
        demo_axis_x = id10_pos['demo_x'] + demo_column * 2870
        demo_axis_y = id10_pos['demo_y'] + demo_row * 2870
        # 计算针管套上过滤嘴后操作的进样瓶坐标
        clean_demo_row = int(clean_demo_pos[i][1] / 3)
        clean_demo_column = clean_demo_pos[i][1] % 3
        clean_demo_axis_x = id11_pos_needle['clean_demo_x'] + clean_demo_column * 2870
        clean_demo_axis_y = id11_pos_needle['clean_demo_y'] + clean_demo_row * 2870
        # 计算继电器封盖橡胶塞操作 进样瓶的坐标
        clean_demo_sip_row = int(clean_demo_pos[i][1] / 3)
        clean_demo_sip_column = clean_demo_pos[i][1] % 3
        clean_demo_sip_axis_x = id11_pos_sip['clean_demo_x'] + clean_demo_column * 2950
        clean_demo_sip_axis_y = id11_pos_sip['clean_demo_y'] + clean_demo_row * 2800

        # 实验前不套针头 不然x轴的归零会碰到针头
        # 实验开始第一步 套针头
        needle_num = change_needles(needle_num)
        needle_fetch(tube_axis_x, tube_axis_y, demo_axis_x, demo_axis_y, 1)
        clean_needle()
        back()
        xaxis_init()
        needle_num = change_needles(needle_num)
        # 稀释混合一步完成后吸取少许反应物
        needle_fetch(id3_dilute_pos['dilute_x'], id3_dilute_pos['dilute_y'], demo_axis_x, demo_axis_y, 2)
        back()
        xaxis_init()
        filter_num = change_filters(filter_num)
        filter_fetch(clean_demo_axis_x,clean_demo_axis_y)
        back()
        #relay_sip(sip_num, clean_demo_sip_axis_x, clean_demo_sip_axis_y)
        xaxis_init()
        needle_num = change_needles(needle_num)
        clean_needle()
        back()