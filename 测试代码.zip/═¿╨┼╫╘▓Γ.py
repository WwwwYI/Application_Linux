
import zmq
import time

if __name__ == '__main__':
    context = zmq.Context()
    skt = context.socket(zmq.PUB)
    skt.bind("tcp://*:5555")
    while True:
        data = bytes('{"receiver":2}', encoding='utf-8')
        data1 = bytes('{"receiver":2,"task":1,"start":true,"stop":false,"currStep":0,"volume_all":[[200,190,200,190],[180,190,200,190]],"scr_pos":[[1,0],[1,1]],"dst_pos":[[5,0],[5,1],[5,2],[5,3]]}', encoding='utf-8')
        data6 = bytes('{"receiver":2,"task":6,"start":true,"stop":false,"currStep":0,"volume_all":[[200,175],[380,390]],"scr_pos":[[6,0],[6,1]],"dst_pos":[[5,0],[5,1]]}', encoding='utf-8')

        skt.send(data6)
        time.sleep(1)

